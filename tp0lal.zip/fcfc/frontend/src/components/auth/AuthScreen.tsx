// সাইনআপ / লগইন স্ক্রিন — অ্যানিমেটেড গ্রেডিয়েন্ট, রিয়েল-টাইম ইউজারনেম চেক,
// নো-রিকভারি সতর্কতা চেকবক্স। সাইনআপে পাসওয়ার্ড দুইবার (কনফার্ম) +
// চোখ-বাটনে শো/হাইড। লগইন Telegram-স্টাইল — সাথে সাথেই সম্পন্ন।
import React, { useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuth } from '../../stores/auth'
import { api } from '../../api/client'
import { Spinner } from '../common'
import { useT } from '../../lib/i18n'
import { IcLock, IcCheck, IcEye, IcEyeOff } from '../../lib/icons'

export default function AuthScreen() {
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [password2, setPassword2] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [understood, setUnderstood] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [nameStatus, setNameStatus] = useState<'idle' | 'checking' | 'ok' | 'taken' | 'invalid'>('idle')
  const t = useT()

  const { login, signup } = useAuth()

  // ইউজারনেম অ্যাভেইলেবিলিটি — টাইপ করার সাথে সাথে চেক
  useEffect(() => {
    if (mode !== 'signup') return
    const u = username.toLowerCase()
    if (!/^[a-z0-9_]{3,24}$/.test(u)) { setNameStatus(u ? 'invalid' : 'idle'); return }
    setNameStatus('checking')
    const timer = setTimeout(async () => {
      try {
        const { ok } = await api(`/auth/check?username=${u}`, { noAuth: true })
        setNameStatus(ok ? 'ok' : 'taken')
      } catch { setNameStatus('idle') }
    }, 450)
    return () => clearTimeout(timer)
  }, [username, mode])

  const mismatch = mode === 'signup' && password2.length > 0 && password !== password2

  const canSubmit = useMemo(() => {
    if (busy) return false
    if (!username || password.length < 8) return false
    if (mode === 'signup') {
      // ইউজারনেম-চেক এন্ডপয়েন্ট (বা সার্ভারের D1) ভেঙে থাকলে nameStatus
      // 'idle'-এ আটকে থাকত — সাইনআপ-বাটন চিরকালের জন্য disabled। এখন
      // শুধু 'taken'/'invalid' হলে বন্ধ; চেক ব্যর্থ হলেও সাবমিট যাবে —
      // সার্ভার সাইনআপে নিজেই username-taken আবার যাচাই করে (409)।
      const nameOk = nameStatus !== 'taken' && nameStatus !== 'invalid'
      return understood && nameOk && password === password2 && password2.length > 0
    }
    return true
  }, [busy, username, password, password2, mode, understood, nameStatus])

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!canSubmit) return
    setBusy(true)
    setError('')
    try {
      const err = mode === 'signup' ? await signup(username, password, understood) : await login(username, password)
      if (err) setError(err)
    } finally {
      setBusy(false)
    }
  }

  const inputCls = 'w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition outline-none'
  const inputPr = showPass ? 'pr-11' : 'pr-4'
  const eyeBtn = 'absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition'

  return (
    <div className="h-full w-full flex items-center justify-center relative overflow-hidden chat-bg">
      {/* অ্যানিমেটেড ব্লার অর্ব */}
      <motion.div className="absolute w-[480px] h-[480px] rounded-full bg-brand-500/25 blur-3xl"
        animate={{ x: [-120, 80, -120], y: [-60, 100, -60] }} transition={{ duration: 18, repeat: Infinity, ease: 'easeInOut' }} />
      <motion.div className="absolute w-[380px] h-[380px] rounded-full bg-violet-500/20 blur-3xl"
        animate={{ x: [100, -90, 100], y: [80, -80, 80] }} transition={{ duration: 22, repeat: Infinity, ease: 'easeInOut' }} />

      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.45, ease: [0.2, 0.9, 0.3, 1] }}
        className="relative w-full max-w-md mx-4 bg-white/85 dark:bg-slate-900/85 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/60 dark:border-slate-700/50 p-8"
      >
        <div className="flex flex-col items-center mb-6">
          <motion.div
            className="w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-500 to-violet-600 flex items-center justify-center text-white text-2xl font-black shadow-lg shadow-brand-500/30"
            whileHover={{ rotate: [0, -6, 6, 0] }} transition={{ duration: 0.5 }}
          >
            fc
          </motion.div>
          <h1 className="mt-3 text-2xl font-bold tracking-tight">fcfc</h1>
          <p className="text-sm text-slate-400 mt-0.5 flex items-center gap-1"><IcLock size={13} /> {t('e2eBadge')}</p>
        </div>

        <AnimatePresence mode="wait">
          <motion.form key={mode} onSubmit={submit} initial={{ opacity: 0, x: mode === 'signup' ? 24 : -24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} className="space-y-4">
            {error && <div className="text-sm text-rose-500 bg-rose-500/10 rounded-xl px-4 py-2.5">{error}</div>}

              <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1">
                {(['login', 'signup'] as const).map((m) => (
                  <button key={m} type="button" onClick={() => { setMode(m); setError(''); setPassword2('') }}
                    className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${mode === m ? 'bg-white dark:bg-slate-700 shadow text-brand-600 dark:text-brand-300' : 'text-slate-400'}`}>
                    {m === 'login' ? t('login') : t('signup')}
                  </button>
                ))}
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{t('username')}</label>
                <div className="relative mt-1">
                  <input value={username} onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, '').toLowerCase())}
                    placeholder={t('usernamePh')} autoComplete="username"
                    className={inputCls} />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-sm">
                    {nameStatus === 'checking' && mode === 'signup' && <Spinner size={16} className="text-slate-400" />}
                    {nameStatus === 'ok' && <span className="text-emerald-500"><IcCheck size={17} /></span>}
                    {nameStatus === 'taken' && <span className="text-rose-500 text-xs font-medium">{t('nameTaken')}</span>}
                    {nameStatus === 'invalid' && username && <span className="text-amber-500 text-xs font-medium">{t('nameInvalid')}</span>}
                  </div>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{t('password')}</label>
                <div className="relative mt-1">
                  <input type={showPass ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)}
                    placeholder={t('passwordPh')} autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                    className={`${inputCls} ${inputPr}`} />
                  <button type="button" onClick={() => setShowPass(!showPass)} className={eyeBtn}
                    title={showPass ? t('hidePass') : t('showPass')} aria-label={showPass ? t('hidePass') : t('showPass')}>
                    {showPass ? <IcEyeOff size={18} /> : <IcEye size={18} />}
                  </button>
                </div>
              </div>

              {/* সাইনআপে পাসওয়ার্ড কনফার্ম + মিসম্যাচ হিন্ট */}
              {mode === 'signup' && (
                <div>
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{t('confirmPass')}</label>
                  <div className="relative mt-1">
                    <input type={showPass ? 'text' : 'password'} value={password2} onChange={(e) => setPassword2(e.target.value)}
                      placeholder={t('passwordPh')} autoComplete="new-password"
                      className={`${inputCls} ${inputPr} ${mismatch ? 'border-rose-400 focus:border-rose-400 focus:ring-rose-500/20' : ''}`} />
                    <button type="button" onClick={() => setShowPass(!showPass)} className={eyeBtn}
                      title={showPass ? t('hidePass') : t('showPass')} aria-label={showPass ? t('hidePass') : t('showPass')}>
                      {showPass ? <IcEyeOff size={18} /> : <IcEye size={18} />}
                    </button>
                    {mismatch && (
                      <div className="text-xs text-rose-500 mt-1 font-medium">{t('passMismatch')}</div>
                    )}
                    {mode === 'signup' && password2.length > 0 && !mismatch && (
                      <div className="absolute right-11 top-1/2 -translate-y-1/2 text-emerald-500"><IcCheck size={16} /></div>
                    )}
                  </div>
                </div>
              )}

              {mode === 'signup' && (
                <label className="flex gap-3 items-start cursor-pointer rounded-xl bg-amber-500/10 border border-amber-500/20 p-3.5 select-none">
                  <input type="checkbox" checked={understood} onChange={(e) => setUnderstood(e.target.checked)}
                    className="mt-0.5 w-4.5 h-4.5 accent-brand-600 scale-110" />
                  <span className="text-[13px] leading-relaxed text-amber-700 dark:text-amber-300/90">
                    {t('noRecovery')}
                  </span>
                </label>
              )}

              {error && <div className="text-sm text-rose-500 bg-rose-500/10 rounded-xl px-4 py-2.5">{error}</div>}

              <motion.button
                whileTap={{ scale: 0.97 }}
                disabled={!canSubmit}
                className="w-full py-3 rounded-xl font-semibold text-white bg-gradient-to-r from-brand-600 to-violet-600 shadow-lg shadow-brand-500/25 disabled:opacity-40 disabled:shadow-none transition flex items-center justify-center gap-2"
              >
                {busy ? <Spinner size={18} /> : mode === 'login' ? t('loginBtn') : t('signupBtn')}
              </motion.button>

              {mode === 'signup' && (
                <p className="text-[11px] text-center text-slate-400 leading-relaxed">
                  {t('signupNote')}
                </p>
              )}
            </motion.form>
        </AnimatePresence>
      </motion.div>
    </div>
  )
}
