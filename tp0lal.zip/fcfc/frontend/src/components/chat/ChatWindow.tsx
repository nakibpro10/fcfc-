// চ্যাট উইন্ডো — হেডার, পিনড বার, মেসেজ লিস্ট (ডেট-সেপারেটর সহ), টাইপিং।
// ব্লকড পিয়ার হলে কম্পোজারের বদলে "আনব্লক করুন" বার দেখায়।
import React, { useEffect, useMemo, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useChats } from '../../stores/chats'
import { useAuth } from '../../stores/auth'
import { useUi } from '../../stores/ui'
import { Avatar, IconTile } from '../common'
import MessageBubble from './MessageBubble'
import Composer from './Composer'
import { chatTitle, } from '../../lib/notify'
import { fmtDay, fmtLastSeen, MUTE_OPTIONS } from '../../lib/utils'
import { useT } from '../../lib/i18n'
import { IcBack, IcPhone, IcVideo, IcSearch, IcMore, IcPin, IcX, IcBellOff, IcBell, IcExport, IcWallpaper, IcTrash, IcTimer, IcUsers, IcInfo, IcUser, IcBlock, IcUnblock } from '../../lib/icons'
import type { Message } from '../../types'

export default function ChatWindow({ chatId }: { chatId: string }) {
  const chat = useChats((s) => s.chats[chatId])
  const messages = useChats((s) => s.messages[chatId] || [])
  const presence = useChats((s) => s.presence)
  const blockedIds = useChats((s) => s.blockedIds)
  const { closeChat, loadHistory, markRead, patchChatState, togglePinMessage } = useChats.getState()
  const { openMenu, openModal, toast, setMobileView, openAvatarView } = useUi.getState()
  const t = useT()
  const bottomRef = useRef<HTMLDivElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const lastCount = useRef(0)

  useEffect(() => {
    // নতুন মেসেজে স্ক্রল
    if (messages.length !== lastCount.current) {
      lastCount.current = messages.length
      requestAnimationFrame(() => bottomRef.current?.scrollIntoView({ behavior: messages.length > 40 ? 'auto' : 'smooth' }))
    }
  }, [messages.length])

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const onScroll = () => {
      if (el.scrollTop < 300 && !useChats.getState().loadedAll[chatId]) {
        const first = useChats.getState().messages[chatId]?.[0]
        if (first) loadHistory(chatId, first.ts)
      }
    }
    el.addEventListener('scroll', onScroll)
    return () => el.removeEventListener('scroll', onScroll)
  }, [chatId])

  // ভিজিবিলিটি: ফোকাসে এলে রিড-রিচিট
  useEffect(() => {
    const vis = () => { if (document.visibilityState === 'visible') markRead(chatId) }
    document.addEventListener('visibilitychange', vis)
    return () => document.removeEventListener('visibilitychange', vis)
  }, [chatId])

  const days = useMemo(() => {
    const out: (Message | { day: string; id: string })[] = []
    let lastDay = ''
    for (const m of messages) {
      const d = new Date(m.ts).toDateString()
      if (d !== lastDay) { lastDay = d; out.push({ day: fmtDay(m.ts), id: 'day-' + d }) }
      out.push(m)
    }
    return out
  }, [messages])

  if (!chat) return null
  const title = chatTitle(chat)
  const typing = (chat.typing || []).map((u) => chat.members.find((m) => m.id === u)?.username || t('someone'))
  const online = chat.kind === 'dm' && chat.peer ? presence[chat.peer.id] : false
  const iBlocked = !!(chat.kind === 'dm' && chat.peer && blockedIds[chat.peer.id])
  const subtitle = typing.length
    ? t('typingMulti', { names: typing.join(', ') })
    : chat.kind === 'group'
      ? t('membersCount', { n: chat.members.length })
      : online ? t('online')
      : chat.peer?.deleted ? t('accountDeleted')
      : chat.peer?.lastSeenPriv === 'nobody' ? t('lastSeenHidden')
      : t('lastSeenAt', { when: fmtLastSeen(chat.peer?.lastSeenAt) })

  const pinnedMsgs = (chat.pins || []).map((id) => messages.find((m) => m.id === id)).filter(Boolean) as Message[]

  function headerMenu(e: React.MouseEvent) {
    openMenu(e.clientX, e.clientY, [
      {
        label: t('searchInChat'),
        icon: <IconTile from="#3b82f6" to="#06b6d4"><IcSearch size={15} /></IconTile>,
        onClick: () => openModal('search', { chatId }),
      },
      {
        label: t('changeWallpaper'),
        icon: <IconTile from="#8b5cf6" to="#a855f7"><IcWallpaper size={15} /></IconTile>,
        onClick: () => openModal('wallpaper', { chatId }),
      },
      {
        label: chat.mutedUntil && chat.mutedUntil > Date.now() ? t('unmute') : t('mute8h'),
        icon: chat.mutedUntil && chat.mutedUntil > Date.now()
          ? <IconTile from="#10b981" to="#34d399"><IcBell size={15} /></IconTile>
          : <IconTile from="#64748b" to="#94a3b8"><IcBellOff size={15} /></IconTile>,
        onClick: () => patchChatState(chatId, { mutedUntil: chat.mutedUntil && chat.mutedUntil > Date.now() ? 0 : Date.now() + MUTE_OPTIONS[0].ms }),
      },
      {
        label: chat.ttl ? t('disappOff') : t('disapp24'),
        icon: <IconTile from="#f59e0b" to="#fbbf24"><IcTimer size={15} /></IconTile>,
        onClick: () => patchChatState(chatId, { ttl: chat.ttl ? 0 : 86400 }),
      },
      {
        label: t('exportChat'),
        icon: <IconTile from="#0ea5e9" to="#38bdf8"><IcExport size={15} /></IconTile>,
        onClick: () => useChats.getState().exportChat(chatId),
      },
      chat.kind === 'group'
        ? {
            label: t('groupInfo'),
            icon: <IconTile from="#6366f1" to="#8b5cf6"><IcInfo size={15} /></IconTile>,
            onClick: () => openModal('group-info', { chatId }),
          }
        : {
            label: t('viewProfile'),
            icon: <IconTile from="#6366f1" to="#8b5cf6"><IcUser size={15} /></IconTile>,
            onClick: () => openModal('profile', { userId: chat.peer?.id }),
          },
      ...(chat.kind === 'dm' ? [{
        label: t('deleteChatMe'), danger: true,
        icon: <IconTile from="#ef4444" to="#f87171"><IcTrash size={15} /></IconTile>,
        onClick: () => { patchChatState(chatId, { deleteForMe: true }); closeChat(); toast(t('chatDeletedToast')) },
      }] : []),
    ])
  }

  return (
    <div className="h-full flex flex-col relative chat-bg wallpaper-cover" style={chat.wallpaper ? { backgroundImage: `url(${chat.wallpaper})` } : undefined}>
      {/* হেডার */}
      <div className="flex items-center gap-2.5 px-3 py-2 bg-white/90 dark:bg-slate-900/90 backdrop-blur border-b border-slate-200/60 dark:border-slate-800 z-10">
        <button onClick={() => { setMobileView('list'); closeChat() }} className="md:hidden p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><IcBack size={20} /></button>
        <button className="flex items-center gap-3 flex-1 min-w-0 text-left" onClick={() => openModal(chat.kind === 'group' ? 'group-info' : 'profile', chat.kind === 'group' ? { chatId } : { userId: chat.peer?.id })}>
          {/* অ্যাভাটারে ক্লিক → হোয়াটসঅ্যাপের মতো বড় করে দেখা */}
          <Avatar name={title} id={chatId} avatarKey={chat.kind === 'group' ? chat.photoKey : chat.peer?.avatarKey} size={42} online={!!online}
            onClick={() => openAvatarView(title, chat.kind === 'group' ? chatId : chat.peer?.id || chatId, chat.kind === 'group' ? chat.photoKey : chat.peer?.avatarKey)} />
          <div className="min-w-0">
            <div className="font-semibold text-[15px] truncate">{title}</div>
            <div className={`text-xs truncate ${typing.length ? 'text-brand-500 font-medium' : 'text-slate-400'}`}>{subtitle}</div>
          </div>
        </button>

        {/* চলমান কল ব্যানার */}
        <AnimatePresence>
          {chat.activeCall && (
            <motion.button initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
              onClick={() => useUi.getState().setCall({ chatId, mode: 'video' })}
              className="px-3 py-1.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> {t('callOngoing')}
            </motion.button>
          )}
        </AnimatePresence>

        {/* ব্লকড পিয়ারে কল-বাটন নেই — আনব্লক করলেই ফিরে আসে */}
        {!iBlocked && (
          <>
            <button onClick={() => useUi.getState().setCall({ chatId, mode: 'audio' })} className="p-2 rounded-full text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"><IcPhone size={20} /></button>
            <button onClick={() => useUi.getState().setCall({ chatId, mode: 'video' })} className="p-2 rounded-full text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"><IcVideo size={21} /></button>
          </>
        )}
        <button onClick={() => openModal('search', { chatId })} className="p-2 rounded-full text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition hidden sm:block"><IcSearch size={19} /></button>
        <button onClick={headerMenu} className="p-2 rounded-full text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"><IcMore size={20} /></button>
      </div>

      {/* পিনড মেসেজ বার */}
      <AnimatePresence>
        {pinnedMsgs.length > 0 && (
          <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }}
            className="overflow-hidden bg-white/80 dark:bg-slate-900/80 backdrop-blur border-b border-slate-200/50 dark:border-slate-800 z-10">
            <div className="flex items-center gap-2.5 px-4 py-2">
              <IcPin size={16} className="text-brand-500 shrink-0" />
              <div className="flex-1 min-w-0 text-[13px]">
                <span className="font-semibold text-brand-600 dark:text-brand-300">{t('pinnedLabel')}</span>
                <span className="opacity-70 truncate ml-2">{pinnedMsgs[pinnedMsgs.length - 1]?.body || t('nPinnedMsgs', { n: pinnedMsgs.length })}</span>
              </div>
              {pinnedMsgs.length > 1 && <span className="text-xs opacity-50">1/{pinnedMsgs.length}</span>}
              <button onClick={() => togglePinMessage(chatId, pinnedMsgs[pinnedMsgs.length - 1].id)} className="opacity-50 hover:opacity-100"><IcX size={16} /></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* মেসেজ লিস্ট */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto overscroll-contain py-3">
        {messages.length === 0 && (
          <div className="h-full flex items-center justify-center">
            <div className="px-5 py-3 rounded-2xl bg-black/25 dark:bg-black/40 text-white/90 text-sm backdrop-blur text-center">
              {t('encryptedNotice')}
            </div>
          </div>
        )}
        {days.map((item) =>
          'day' in item ? (
            <div key={item.id} className="flex justify-center my-3">
              <span className="px-3 py-1 rounded-full bg-black/20 dark:bg-black/40 text-white/90 text-xs font-medium backdrop-blur">{item.day}</span>
            </div>
          ) : (
            <MessageBubble key={item.id} msg={item} chat={chat} prev={messages[messages.indexOf(item) - 1]} />
          ),
        )}
        <AnimatePresence>
          {typing.length > 0 && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex px-3 mt-2">
              <div className="bg-bubble-in dark:bg-[#1c2333] rounded-2xl rounded-bl-md px-4 py-3 shadow-sm border border-slate-200/50 dark:border-slate-700/40 flex gap-1">
                {[0, 1, 2].map((i) => (
                  <motion.span key={i} className="w-1.5 h-1.5 rounded-full bg-slate-400"
                    animate={{ y: [0, -4, 0] }} transition={{ repeat: Infinity, duration: 0.9, delay: i * 0.15 }} />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={bottomRef} />
      </div>

      {/* আমি ব্লক করেছি → কম্পোজারের বদলে আনব্লক-বার (মেসেজ পাঠানো বন্ধ) */}
      {iBlocked && chat.peer ? (
        <div className="px-3 pb-3 pt-1">
          <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-rose-500/10 border border-rose-500/25">
            <IconTile from="#ef4444" to="#f87171"><IcBlock size={17} /></IconTile>
            <div className="flex-1 min-w-0 text-[13px] text-rose-600 dark:text-rose-300 font-medium truncate">
              {t('blockedBar', { name: chat.peer.username })}
            </div>
            <button
              onClick={async () => { await useChats.getState().unblock(chat.peer!.id); toast(t('unblockedToast')) }}
              className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm font-semibold shrink-0 flex items-center gap-1.5"
            >
              <IcUnblock size={16} /> {t('unblock')}
            </button>
          </div>
        </div>
      ) : (
        <Composer chat={chat} />
      )}
    </div>
  )
}
