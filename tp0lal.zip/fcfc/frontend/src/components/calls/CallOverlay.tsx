// ভয়েস/ভিডিও কল — Cloudflare Calls (SFU) + WebRTC।
//
// আর্কিটেকচার (অফিসিয়াল Cloudflare video-room উদাহরণের মতো):
// প্রতিটি পার্টিসিপ্যান্টের **দুটি** PeerConnection + দুটি SFU সেশন —
//   • producer — নিজের মাইক/ক্যামেরা পাঠায় (sendonly ট্রান্সিভার + অফার/আনসার)
//   • consumer — বাকিদের ট্র্যাক টানে (remote-only ব্যাচ → SFU-অফার →
//     আমাদের answer → PUT /calls/renegotiate)
// এক ব্যাচে local+remote ট্র্যাক মেশানো নিষেধ (API নিয়ম) — আগের ভার্সনের
// 400 decoding_error সেজন্যই আসত। mid অফার সেট হওয়ার **পরে** পড়তে হয়।
//
// সিগন্যালিং: activeCall.sessions[uid] = সেই ইউজারের producer-সেশন —
// অন্যরা ওখান থেকেই তার ট্র্যাক pull করে। নতুন পার্টিসিপ্যান্ট এলে
// consumer-সেশনে নতুন remote ট্র্যাক যোগ হয় (রেনেগোসিয়েশন)।
import React, { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useUi } from '../../stores/ui'
import { useAuth } from '../../stores/auth'
import { useChats } from '../../stores/chats'
import { api } from '../../api/client'
import { sendChat } from '../../realtime/sockets'
import { Avatar } from '../common'
import { chatTitle } from '../../lib/notify'
import { useT } from '../../lib/i18n'
import { IcMic, IcMicOff, IcVideo, IcVideoOff, IcScreen, IcPhoneEnd, IcVolume } from '../../lib/icons'

export default function CallOverlay() {
  const call = useUi((s) => s.call)
  const setCall = useUi((s) => s.setCall)
  const me = useAuth.getState().user!
  const t = useT()

  const [participants, setParticipants] = useState<string[]>([])
  const [muted, setMuted] = useState(false)
  const [camOff, setCamOff] = useState(false)
  const [sharing, setSharing] = useState(false)
  const [seconds, setSeconds] = useState(0)
  const [error, setError] = useState('')

  const prodRef = useRef<RTCPeerConnection | null>(null)
  const consRef = useRef<RTCPeerConnection | null>(null)
  const localStreamRef = useRef<MediaStream | null>(null)
  const localVidRef = useRef<HTMLVideoElement>(null)
  const remoteRefs = useRef<Record<string, HTMLVideoElement | null>>({})
  const audioRefs = useRef<Record<string, HTMLAudioElement | null>>({})
  // producer + consumer সেশন-আইডি
  const sessionsRef = useRef<{ prod: string; cons: string; mode: 'audio' | 'video' } | null>(null)
  // consumer ট্রান্সিভারের mid → trackName (`uid:kind`) — ontrack-এ কার মিডিয়া বোঝায়
  const midToName = useRef<Map<string, string>>(new Map())
  // ইতিমধ্যে pull-করা রিমোট ট্র্যাক ("producerSession/trackName")
  const pulled = useRef<Set<string>>(new Set())
  // consumer-সেশনে একবারে একটাই mutation (সিরিয়ালাইজড) — না হলে SFU
  // "পেন্ডিং নেগোসিয়েশন আগে শেষ করুন" এরর দেয়
  const subBusy = useRef(false)
  const subAgain = useRef(false)

  const chat = call ? useChats.getState().chats[call.chatId] : null

  // রিমোট মিডিয়া-স্ট্রিম যুক্ত করি — ভিডিও মোডে টাইলে, সবসময় লুকানো <audio>-তে (ভয়েস কলে শব্দ শোনার জন্য)
  function attachRemote(label: string, stream: MediaStream) {
    setParticipants((p) => (p.includes(label) ? p : [...p, label]))
    setTimeout(() => {
      const v = remoteRefs.current[label]
      if (v && v.srcObject !== stream) v.srcObject = stream
      const a = audioRefs.current[label]
      if (a && a.srcObject !== stream) { a.srcObject = stream; a.play().catch(() => {}) }
    }, 50)
  }

  // সব অ-নিজেস্ব পার্টিসিপ্যান্টের এখনো-pull-হয়নি-এমন রিমোট ট্র্যাক
  // (দুই ধরনেরই চাই — ভিডিও-মোডের পার্টিসিপ্যান্ট অডিও-মোডে ডাকলে ভিডিও-ট্র্যাক
  // পাওয়া যাবে না, SFU ওই আইটেমেই ব্যর্থ ফেরত দেবে — বাকি ট্র্যাক ঠিক চলবে)
  function pendingPulls(chatId: string, myUid: string): any[] {
    const ac = useChats.getState().chats[chatId]?.activeCall
    const out: any[] = []
    for (const [uid, sid] of Object.entries<any>(ac?.sessions || {})) {
      if (uid === myUid || !sid) continue
      for (const kind of ['audio', 'video']) {
        const trackName = `${uid}:${kind}`
        if (pulled.current.has(`${sid}/${trackName}`)) continue
        out.push({ location: 'remote', sessionId: String(sid), trackName })
      }
    }
    return out
  }

  // ট্র্যাক-রেসপন্স প্রসেস — pull-সেট আপডেট + mid→নাম ম্যাপ + পার্টিসিপ্যান্ট চেনা
  function applyTracks(tracks: any[], chatId: string) {
    const members = useChats.getState().chats[chatId]?.members || []
    for (const tr of tracks || []) {
      if (!tr || tr.location !== 'remote' || !tr.mid) continue
      if (tr.trackName) midToName.current.set(String(tr.mid), String(tr.trackName))
      if (tr.sessionId && tr.trackName) pulled.current.add(`${tr.sessionId}/${tr.trackName}`)
      const uid = String(tr.trackName || '').split(':')[0]
      if (uid) {
        const uname = members.find((m) => m.id === uid)?.username || uid
        setParticipants((p) => (p.includes(uname) ? p : [...p, uname]))
      }
    }
  }

  // রিমোট ট্র্যাক subscribe — স্পেসিফিকেশন-ক্যানোনিক্যাল ক্রম:
  //   ১) tracks/new {tracks:[remote]} — sessionDescription ছাড়া
  //   ২) SFU-অফার এলে setRemoteDescription → createAnswer → setLocalDescription
  //   ৩) PUT /calls/renegotiate — answer জমা
  //   ৪) API না নেওয়া পর্যন্ত পরের mutation নয় (সিরিয়াল)
  async function subscribe(chatId: string) {
    const cons = consRef.current
    const info = sessionsRef.current
    if (!cons || !info) return
    if (subBusy.current) { subAgain.current = true; return }
    const pulls = pendingPulls(chatId, me.id)
    if (!pulls.length) return
    subBusy.current = true
    try {
      const res = await api('/calls/negotiate', {
        body: { sessionId: info.cons, body: { tracks: pulls } },
      })
      applyTracks(res.tracks, chatId)
      if (res.requiresImmediateRenegotiation && res.sessionDescription) {
        await cons.setRemoteDescription(res.sessionDescription)
        const answer = await cons.createAnswer()
        await cons.setLocalDescription(answer)
        await api('/calls/renegotiate', {
          method: 'PUT',
          body: { sessionId: info.cons, body: { sessionDescription: { type: 'answer', sdp: answer.sdp } } },
        })
      }
    } catch (e) {
      console.warn('subscribe failed', e)
    } finally {
      subBusy.current = false
      if (subAgain.current) { subAgain.current = false; subscribe(chatId).catch(() => {}) }
    }
  }

  function newPc(): RTCPeerConnection {
    // অফিসিয়াল উদাহরণের কনফিগ: max-bundle + Cloudflare-এর নিজের STUN
    return new RTCPeerConnection({
      bundlePolicy: 'max-bundle',
      iceServers: [{ urls: 'stun:stun.cloudflare.com:3478' }],
    })
  }

  useEffect(() => {
    if (!call) return
    let dead = false
    let unsub: (() => void) | null = null
    const timer = setInterval(() => setSeconds((s) => s + 1), 1000)
    setParticipants([me.username])

    ;(async () => {
      try {
        // চলমান কলের তথ্য — জয়েনার হলে মোড জানা থাকে
        const existing = useChats.getState().chats[call.chatId]?.activeCall
        const joining = !!(existing?.sessions && Object.keys(existing.sessions).length)
        const mode: 'audio' | 'video' = (joining ? existing?.mode : call.mode) || 'audio'

        // ১. নিজের দুটি SFU সেশন — producer (পাঠানো) + consumer (টানা)
        const [p, c] = await Promise.all([
          api('/calls/session', { body: { chatId: call.chatId } }),
          api('/calls/session', { body: { chatId: call.chatId } }),
        ])
        if (!p.sessionId || !c.sessionId) throw new Error(p.message || c.message || t('noSession'))
        if (dead) return
        sessionsRef.current = { prod: String(p.sessionId), cons: String(c.sessionId), mode }
        // সিগন্যালিং-স্টেটে আমার producer-সেশন জানিয়ে দিই — অন্যরা এটা থেকেই
        // আমার ট্র্যাক pull করবে
        useChats.getState().mergeCallSession(call.chatId, me.id, String(p.sessionId))

        // ২. মিডিয়া
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: mode === 'video' ? { width: { ideal: 1280 }, height: { ideal: 720 } } : false,
        })
        if (dead) { stream.getTracks().forEach((tr) => tr.stop()); return }
        localStreamRef.current = stream
        if (localVidRef.current && mode === 'video') localVidRef.current.srcObject = stream

        // ৩. producer PC — sendonly ট্রান্সিভার, অফার, mid তারপর পড়া
        const prod = newPc()
        prodRef.current = prod
        const transceivers: RTCRtpTransceiver[] = []
        for (const track of stream.getTracks()) {
          transceivers.push(prod.addTransceiver(track, { direction: 'sendonly' }))
        }
        const offer = await prod.createOffer()
        await prod.setLocalDescription(offer)
        // ⚠️ mid অফার সেট হওয়ার আগে পড়লে সবসময় undefined পড়ত — আগের
        // বাগ; স্পেসিফিকেশনেও mid বাধ্যতামূলক (offer-সহ publish-এ)
        const trackEntries = transceivers.map((tc) => ({
          location: 'local',
          mid: String(tc.mid ?? ''),
          trackName: `${me.id}:${tc.sender.track?.kind || 'audio'}`,
        })).filter((e) => e.mid !== '')
        const pubRes = await api('/calls/negotiate', {
          body: {
            sessionId: sessionsRef.current.prod,
            body: { sessionDescription: { type: 'offer', sdp: offer.sdp }, tracks: trackEntries },
          },
        })
        if (dead) return
        if (pubRes.sessionDescription) await prod.setRemoteDescription(pubRes.sessionDescription)

        // ৪. consumer PC — রিমোট ট্র্যাকের জন্য; ontrack-এ mid→trackName ম্যাপ
        const cons = newPc()
        consRef.current = cons
        cons.ontrack = (e) => {
          const stream2 = e.streams[0] || new MediaStream([e.track])
          const name = midToName.current.get(String((e.transceiver as any)?.mid)) || ''
          const uid = name ? name.split(':')[0] : ''
          const members = useChats.getState().chats[call.chatId]?.members || []
          const label = uid ? (members.find((m) => m.id === uid)?.username || uid) : t('guest')
          attachRemote(label, stream2)
        }

        // ৫. চলমান কলের বাকিদের ট্র্যাক টানি (জয়েনার হলে)
        if (joining) await subscribe(call.chatId)

        // ৬. সিগন্যালিং — অন্যদের জানাই (start নতুন কল, join চলমান কলে)
        if (joining) {
          sendChat(call.chatId, { t: 'call', chatId: call.chatId, action: 'join', join: { sessionId: sessionsRef.current.prod } })
        } else {
          sendChat(call.chatId, { t: 'call', chatId: call.chatId, action: 'start', call: { sessionId: sessionsRef.current.prod, mode } })
        }

        // ৭. নতুন পার্টিসিপ্যান্ট এলে তার ট্র্যাক subscribe — activeCall.sessions-পরিবর্তন শোনা
        unsub = useChats.subscribe((s, prev) => {
          const now2 = s.chats[call.chatId]?.activeCall?.sessions
          const before = prev.chats[call.chatId]?.activeCall?.sessions
          if (now2 && now2 !== before) subscribe(call.chatId).catch(() => {})
        })
      } catch (e: any) {
        console.error(e)
        setError(e.message || t('callNotStarted'))
        // শুরুতেই ব্যর্থ (মাইক্রোফোন-পারমিশন ইত্যাদি) — আগে মার্জ করা
        // নিজের সেশন-এন্ট্রি আর "Call in progress" ব্যানার রেখে দিলে ভুয়া
        // চলমান-কল দেখাত — পরিষ্কার করে দিই
        try {
          const s = useChats.getState()
          const ac = s.chats[call.chatId]?.activeCall
          if (ac?.sessions && sessionsRef.current && ac.sessions[me.id] === sessionsRef.current.prod) {
            const sessions = { ...ac.sessions }
            delete sessions[me.id]
            useChats.setState((st) => ({ chats: { ...st.chats, [call.chatId]: { ...st.chats[call.chatId], activeCall: Object.keys(sessions).length ? { ...ac, sessions } : null } } }))
          }
        } catch {}
      }
    })()

    return () => {
      dead = true
      clearInterval(timer)
      unsub?.()
      teardown()
      const info = sessionsRef.current
      if (info) {
        // দুটি সেশনেরই ম্যাপিং মুছি + সংকেত দিই
        api('/calls/session/close', { body: { sessionId: info.prod } }).catch(() => {})
        api('/calls/session/close', { body: { sessionId: info.cons } }).catch(() => {})
        sendChat(call.chatId, { t: 'call', chatId: call.chatId, action: 'end' })
      }
      sessionsRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [call?.chatId, call?.mode])

  function teardown() {
    localStreamRef.current?.getTracks().forEach((tr) => tr.stop())
    try { prodRef.current?.close() } catch {}
    try { consRef.current?.close() } catch {}
    prodRef.current = null
    consRef.current = null
    localStreamRef.current = null
    midToName.current.clear()
    pulled.current.clear()
  }

  async function toggleShare() {
    const prod = prodRef.current
    if (!prod) return
    try {
      if (!sharing) {
        const ds = await navigator.mediaDevices.getDisplayMedia({ video: true })
        const screenTrack = ds.getVideoTracks()[0]
        const sender = prod.getSenders().find((s) => s.track?.kind === 'video')
        if (sender) await sender.replaceTrack(screenTrack)
        screenTrack.onended = () => { sender?.replaceTrack(localStreamRef.current?.getVideoTracks()[0] || null); setSharing(false) }
        setSharing(true)
      } else {
        const sender = prod.getSenders().find((s) => s.track?.kind === 'video')
        const cam = localStreamRef.current?.getVideoTracks()[0] || null
        if (sender && cam) await sender.replaceTrack(cam)
        setSharing(false)
      }
    } catch {}
  }

  if (!call) return null
  const title = chat ? chatTitle(chat) : t('callT')
  const dur = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      // ⚠️ লাইট-মোড বাগের মূল কারণ: আগে bg-[#0b0f1a]/97 লেখা হয়েছিল —
      // Tailwind অপাসিটি মডিফায়ার ৫-এর ধাপে (…/90 /95 /100) না হলে ক্লাস
      // জেনারেটই হয় না, তাই ওভারলে স্বচ্ছ থেকে যেত — লাইট মোডে সাদা
      // টেক্সট/বাটন অদৃশ্য, ডার্ক মোডে ঠিক দেখাত। এখন inline rgba — বুলেটপ্রুফ।
      style={{ backgroundColor: 'rgba(11, 15, 26, 0.96)' }}
      className="fixed inset-0 z-[75] backdrop-blur flex flex-col">
      {/* উপরের সেন্টারে পার্টিসিপ্যান্ট (টেলিগ্রাম-স্টাইল) */}
      <div className="pt-5 flex flex-col items-center gap-1.5">
        <div className="text-white font-semibold text-lg">{title}</div>
        <div className="text-white/50 text-sm">{error ? error : dur}</div>
        <div className="flex items-center gap-1.5 flex-wrap justify-center max-w-md px-4">
          {participants.map((p, i) => (
            <motion.span key={i} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }}
              className="px-3 py-1 rounded-full bg-white/10 text-white/85 text-xs font-medium flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />{p.replace('remote-', t('guest') + ' ')}
            </motion.span>
          ))}
        </div>
      </div>

      {/* ভিডিও গ্রিড */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="grid gap-3" style={{ gridTemplateColumns: `repeat(${Math.min(participants.length, 2)}, minmax(0, 1fr))` }}>
          {call.mode === 'video' ? (
            <>
              {participants.map((p, i) => (
                <div key={i} className="relative w-[300px] h-[200px] md:w-[420px] md:h-[280px] rounded-2xl overflow-hidden bg-slate-800">
                  {i === 0 ? (
                    <video ref={localVidRef} muted playsInline className="w-full h-full object-cover" />
                  ) : (
                    <RemoteTile id={p} refs={remoteRefs} />
                  )}
                  <span className="absolute bottom-2 left-2.5 px-2 py-0.5 rounded-md bg-black/50 text-white text-xs">{i === 0 ? t('you') : p}</span>
                </div>
              ))}
            </>
          ) : (
            <div className="flex flex-col items-center gap-4">
              <motion.div animate={{ scale: [1, 1.06, 1] }} transition={{ repeat: Infinity, duration: 2 }}
                className="w-28 h-28 rounded-full bg-gradient-to-br from-brand-500 to-violet-600 flex items-center justify-center text-white text-4xl font-bold shadow-2xl shadow-brand-500/40">
                {title.slice(0, 1).toUpperCase()}
              </motion.div>
              <div className="text-white/70 text-sm flex items-center gap-1.5"><IcVolume size={15} /> {t('voiceCallTag')}</div>
              {/* ভয়েস কলে ভিডিও-টাইল নেই — রিমোট অডিও এই লুকানো এলিমেন্টে বাজে */}
              <div className="hidden">
                {participants.slice(1).map((p) => <audio key={p} ref={(el) => { audioRefs.current[p] = el }} autoPlay playsInline />)}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* কন্ট্রোল */}
      <div className="pb-8 flex items-center justify-center gap-4">
        <CallBtn on={!muted} onClick={() => { const tr = localStreamRef.current?.getAudioTracks()[0]; if (tr) { tr.enabled = muted; setMuted(!muted) } }}>
          {muted ? <IcMicOff size={22} /> : <IcMic size={22} />}
        </CallBtn>
        {call.mode === 'video' && (
          <CallBtn on={!camOff} onClick={() => { const tr = localStreamRef.current?.getVideoTracks()[0]; if (tr) { tr.enabled = camOff; setCamOff(!camOff) } }}>
            {camOff ? <IcVideoOff size={22} /> : <IcVideo size={22} />}
          </CallBtn>
        )}
        <CallBtn on={!sharing} onClick={toggleShare}><IcScreen size={22} /></CallBtn>
        <motion.button whileTap={{ scale: 0.9 }} onClick={() => { teardown(); setCall(null) }}
          className="w-14 h-14 rounded-full bg-rose-500 text-white flex items-center justify-center shadow-lg shadow-rose-500/40">
          <IcPhoneEnd size={24} />
        </motion.button>
      </div>
    </motion.div>
  )
}

function RemoteTile({ id, refs }: { id: string; refs: any }) {
  return <video ref={(el) => { refs.current[id] = el }} autoPlay playsInline className="w-full h-full object-cover bg-black" />
}

function CallBtn({ children, onClick, on }: { children: React.ReactNode; onClick: () => void; on: boolean }) {
  return (
    <motion.button whileTap={{ scale: 0.9 }} onClick={onClick}
      className={`w-12 h-12 rounded-full flex items-center justify-center transition ${on ? 'bg-white/10 text-white' : 'bg-white text-slate-900'}`}>
      {children}
    </motion.button>
  )
}
