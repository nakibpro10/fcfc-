// লোকাল/পুশ নোটিফিকেশন হেল্পার + নোটিফিকেশন সাউন্ড (সিন্থেসাইজড পিং)।
import type { Chat, Message } from '../types'
import { useChats } from '../stores/chats'
import { t } from '../lib/i18n'

export function chatTitle(c: Chat): string {
  if (c.kind === 'group') return c.title || t('groupFallback')
  return c.peer?.deleted ? t('deletedAccount') : c.peer?.username || t('chatFallback')
}

export function notifyMessage(chat: Chat, msg: Message) {
  try {
    if (!('Notification' in window)) return
    if (Notification.permission !== 'granted') return
    // অ্যাপ ফোকাসে ও একই চ্যাট খোলা থাকলে ট্রে-তে দেখানোর দরকার নেই।
    // (অ্যাপটি হ্যাশ-ভিত্তিক — আগে location.search দেখা হতো, যা কখনোই ম্যাচ করত না)
    if (document.hasFocus() && useChats.getState().activeChatId === msg.chatId) return
    const title = chatTitle(chat)
    const body = msg.body || t('encryptedMsgBody')
    new Notification(title, {
      body: body.slice(0, 120),
      tag: `msg-${msg.id}`,
      icon: '/icons/icon-192.png',
      badge: '/icons/icon-192.png',
      data: { chatId: msg.chatId },
    })
  } catch {}
}

export async function requestNotifyPermission(): Promise<boolean> {
  if (!('Notification' in window)) return false
  if (Notification.permission === 'default') await Notification.requestPermission()
  return Notification.permission === 'granted'
}

let audioCtx: AudioContext | null = null
// অটোপ্লে-পলিসি: AudioContext প্রথম ইনকামিং মেসেজে (ইউজার-জেসচার ছাড়া)
// তৈরি হলে "suspended" থেকে যায় — পিং নীরব থাকত। প্রথম ইন্টারঅ্যাকশনে আনলক।
try {
  const unlock = () => {
    try {
      audioCtx = audioCtx || new AudioContext()
      void audioCtx.resume()
    } catch {}
    window.removeEventListener('pointerdown', unlock)
    window.removeEventListener('keydown', unlock)
  }
  window.addEventListener('pointerdown', unlock)
  window.addEventListener('keydown', unlock)
} catch {}

export function playPing() {
  try {
    audioCtx = audioCtx || new AudioContext()
    if (audioCtx.state === 'suspended') void audioCtx.resume()
    const t = audioCtx.currentTime
    const osc = audioCtx.createOscillator()
    const gain = audioCtx.createGain()
    osc.type = 'sine'
    osc.frequency.setValueAtTime(880, t)
    osc.frequency.exponentialRampToValueAtTime(1318, t + 0.08)
    gain.gain.setValueAtTime(0.001, t)
    gain.gain.exponentialRampToValueAtTime(0.18, t + 0.02)
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.35)
    osc.connect(gain).connect(audioCtx.destination)
    osc.start(t)
    osc.stop(t + 0.4)
  } catch {}
}
