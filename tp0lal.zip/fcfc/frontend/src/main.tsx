import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'
import { registerServiceWorker } from './pwa/register'
import { useI18n } from './lib/i18n'
import { applyThemeColor } from './stores/ui'

// থিম আগে থেকেই প্রয়োগ (ফ্ল্যশ এড়াতে)
try {
  const t = localStorage.getItem('fcfc.theme')
  if (t === 'dark' || (!t && matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.documentElement.classList.add('dark')
  }
} catch {}

// PWA থিম-কালার: অ্যাপের থিম অনুযায়ী স্ট্যাটাস-বারের রঙ (আগে সবসময় নীল ছিল)
try { applyThemeColor(document.documentElement.classList.contains('dark') ? 'dark' : 'light') } catch {}

// ভাষা অনুযায়ী <html lang> সেট (ডিফল্ট ইংরেজি)
try {
  const lang = useI18n.getState().lang
  document.documentElement.lang = lang === 'bn' ? 'bn' : 'en'
} catch {}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)

registerServiceWorker()
