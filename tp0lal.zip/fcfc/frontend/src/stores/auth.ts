// অথেনটিকেশন স্টেট — সাইনআপ, লগইন (Telegram-স্টাইল), কী রিস্টোর/আপলোড।
import { create } from 'zustand'
import { api, setTokens, getTokens } from '../api/client'
import { createIdentityBundle, loadIdentityBundle, publicBundleForUpload } from '../crypto/keys'
import { syncBackup, createBackup, restoreBackup } from '../crypto/backup'
import { idb } from '../lib/db'
import { b64u } from '../lib/utils'
import { t } from '../lib/i18n'
import type { User } from '../types'

// ভারী পাসওয়ার্ড-হ্যাশিং ব্রাউজারেই হয় (Workers ফ্রি প্ল্যানের ১০ms CPU-লিমিটের কারণে)।
// সার্ভারে পাঠানো হয় PBKDF2-ডিরাইভড হ্যাশ, আসল পাসওয়ার্ড নয়।
async function clientPassHash(username: string, password: string): Promise<string> {
  const salt = new TextEncoder().encode('fcfc-v1:' + username.toLowerCase())
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits'])
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', hash: 'SHA-256', salt: salt as BufferSource, iterations: 600_000 },
    base, 256,
  )
  return b64u(new Uint8Array(bits))
}

export type BootStatus = 'boot' | 'auth' | 'ready'

interface AuthState {
  status: BootStatus
  user: User | null
  settings: any
  password: string | null // শুধু ব্যাকআপ সিঙ্কের জন্য সেশন-মেমোরিতে

  boot(): Promise<void>
  signup(username: string, password: string, understood: boolean): Promise<string | null>
  login(username: string, password: string): Promise<string | null>
  decideDevice(deviceId: string, accept: boolean): Promise<void>
  updateProfile(patch: Record<string, any>): Promise<void>
  updateSettings(patch: Record<string, any>): Promise<void>
  deleteAccount(password: string): Promise<string | null>
  logout(remote?: boolean): Promise<void>
  forceLogout(): void
}

const deviceName = () => {
  const ua = navigator.userAgent
  const browser = ua.includes('Firefox') ? 'Firefox' : ua.includes('Edg') ? 'Edge' : ua.includes('Chrome') ? 'Chrome' : 'Safari'
  const os = ua.includes('Windows') ? 'Windows' : ua.includes('Mac') ? 'macOS' : ua.includes('Android') ? 'Android' : ua.includes('Linux') ? 'Linux' : ua.includes('iPhone') ? 'iOS' : 'Device'
  return `${browser} · ${os}`
}

// একই ব্রাউজারে অন্য অ্যাকাউন্টে লগইন করলে পুরনো অ্যাকাউন্টের কী/সেশন/
// মেসেজ-ক্যাশ রয়ে গিয়ে নতুন অ্যাকাউন্টের কী-বান্ডল দূষিত করত — ডেটা আগে
// মুছে নতুন শুরু। (নিজের একই অ্যাকাউন্টে লগআউট→লগইনে ডেটা অক্ষত থাকে।)
async function ensureLocalOwner(userId: string) {
  try {
    const owner = await idb.get<string>('meta', 'owner')
    if (owner && owner !== userId) {
      await wipeLocalCrypto()
    }
    await idb.put('meta', 'owner', userId)
  } catch {}
}

async function wipeLocalCrypto() {
  await Promise.all(['keys', 'sessions', 'senderKeys', 'messages', 'starred', 'meta'].map((s) => idb.clear(s)))
}

// ⚠️ সাইনআপের ক্রম-বাগ: আগে createIdentityBundle() চলত, তারপর
// ensureLocalOwner() — ব্রাউজারে আগে অন্য অ্যাকাউন্টের ডেটা থাকলে এই মুছে-
// যাওয়া ধাপটাই **সদ্য-তৈরি নতুন কীগুলোও** মুছে দিত → প্রতিটি মেসেজ পাঠানো
// "identity not ready" এররে ব্যর্থ ("message adan-prodan problem")।
// সাইনআপ মানেই নতুন অ্যাকাউন্ট — আগের যে-কোনো লোকাল ডেটা অন্য অ্যাকাউন্টের,
// তাই কী বানানোর **আগেই** পরিষ্কার করে নিই।
async function wipeIfOtherAccount() {
  try {
    const owner = await idb.get<string>('meta', 'owner')
    if (owner) await wipeLocalCrypto()
  } catch {}
}

export const useAuth = create<AuthState>((set, get) => ({
  status: 'boot',
  user: null,
  settings: {},
  password: null,

  async boot() {
    const toks = getTokens()
    if (!toks) return set({ status: 'auth' })
    try {
      const { user, settings } = await api('/me')
      set({ user, settings: settings || {}, status: 'ready' })
    } catch {
      setTokens(null)
      set({ status: 'auth' })
    }
  },

  async signup(username, password, understood) {
    try {
      // অন্য অ্যাকাউন্টের পুরনো ডেটা আগেই মুছি — নইলে নিচের কী বানানোর
      // পরে ensureLocalOwner সেগুলো আবার মুছে দিত (ক্রম-বাগ)
      await wipeIfOtherAccount()
      // কী-পেয়ার আগেই তৈরি হয়, তারপর অ্যাকাউন্ট
      const bundle = await createIdentityBundle()
      const keys = await publicBundleForUpload(bundle)
      const passHash = await clientPassHash(username, password)
      const res = await api('/auth/signup', {
        noAuth: true,
        body: { username, password: passHash, understood, deviceName: deviceName(), keys },
      })
      setTokens({ access: res.access, refresh: res.refresh })
      set({ password })
      await ensureLocalOwner(res.user.id)
      const { user, settings } = await api('/me')
      set({ user, settings: settings || {}, status: 'ready' })
      await syncBackup(password)
      return null
    } catch (e: any) {
      return e.message || t('signupFailed')
    }
  },

  // Telegram-স্টাইল লগইন: পাসওয়ার্ড মিললেই টোকেন পাওয়া যায় — কোনো
  // পোলিং/অপেক্ষা নেই। পুরনো ডিভাইসগুলোতে নোটিফিকেশন যায়; সেখান থেকে
  // Decline করলে সার্ভার এই ডিভাইসের সেশন রিভোক করে দেয়।
  async login(username, password) {
    try {
      const passHash = await clientPassHash(username, password)
      const res = await api('/auth/login', { noAuth: true, body: { username, password: passHash, deviceName: deviceName() } })
      return finishLogin(set, get, res.access, res.refresh, password)
    } catch (e: any) {
      return e.message || t('loginFailed')
    }
  },

  async decideDevice(deviceId, accept) {
    await api(`/auth/devices/${deviceId}/decision`, { body: { accept } })
  },

  async updateProfile(patch) {
    await api('/me', { method: 'PATCH', body: patch })
    const { user } = await api('/me')
    set({ user })
  },

  async updateSettings(patch) {
    const merged = { ...get().settings, ...patch }
    await api('/me', { method: 'PATCH', body: { settings: merged } })
    set({ settings: merged })
  },

  async deleteAccount(password) {
    try {
      const me = get().user
      const passHash = await clientPassHash(me?.username || '', password)
      await api('/me/account', { method: 'DELETE', body: { password: passHash } })
      setTokens(null)
      set({ user: null, status: 'auth', password: null })
      return null
    } catch (e: any) {
      return e.message || t('failedRetry')
    }
  },

  async logout(remote = false) {
    try { await api('/auth/logout', { body: { device: remote } }) } catch {}
    setTokens(null)
    set({ user: null, status: 'auth', password: null })
  },

  forceLogout() {
    setTokens(null)
    set({ user: null, status: 'auth', password: null })
  },
}))

window.addEventListener('fcfc:force-logout', () => useAuth.getState().forceLogout())

async function finishLogin(set: any, get: any, access: string, refresh: string, password: string) {
  setTokens({ access, refresh })
  set({ password })
  const { user, settings } = await api('/me')
  await ensureLocalOwner(user.id)
  set({ user, settings: settings || {}, status: 'ready' })

  // কী রিস্টোরেশন: লোকালে কী আছে? নাহলে পাসওয়ার্ড দিয়ে ব্যাকআপ থেকে
  const hasLocal = !!(await idb.get('keys', 'identity'))
  if (!hasLocal) {
    const backup = await api('/me/backup')
    if (backup?.blob) {
      await restoreBackup(password, backup.blob, backup.salt)
    } else {
      // নতুন ডিভাইস + কোনো ব্যাকআপ নেই → নতুন আইডেন্টিটি
      const bundle = await createIdentityBundle()
      await api('/me/keys', { body: await publicBundleForUpload(bundle) })
      const { blob, salt } = await createBackup(password)
      await api('/me/backup', { method: 'PUT', body: { blob, salt } })
    }
  } else {
    await syncBackup(password).catch(() => {})
  }
  return null
}
