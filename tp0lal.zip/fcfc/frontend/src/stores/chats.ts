// মূল চ্যাট স্টোর — রিয়েল-টাইম মেসেজ, এনক্রিপশন/ডিক্রিপশন, রিসিট, ভ্যানিশ,
// রিয়্যাকশন, পিন, স্টার, টাইপিং, প্রেজেন্স, সার্চ, এক্সপোর্ট।
import { create } from 'zustand'
import { api, deviceId } from '../api/client'
import { handlers, connectChat, disconnectChat, sendChat, connectHub, resetSockets } from '../realtime/sockets'
import { encryptFor, decryptFrom, type Envelope } from '../crypto/sessions'
import * as sk from '../crypto/sender'
import { idb } from '../lib/db'
import { uid, URL_RE } from '../lib/utils'
import { useAuth } from './auth'
import { notifyMessage, playPing } from '../lib/notify'
import { t } from '../lib/i18n'
import { markBackupDirty } from '../crypto/backup'
import type { Chat, Message, SendDraft } from '../types'

interface ChatsState {
  booted: boolean
  chats: Record<string, Chat>
  messages: Record<string, Message[]>
  loadedAll: Record<string, boolean>
  activeChatId: string | null
  presence: Record<string, boolean>
  requests: any[]
  vanish: Record<string, boolean>
  starredIds: Record<string, boolean>
  seenBy: Record<string, string[]>
  replyingTo: Message | null
  blockedIds: Record<string, boolean>

  boot(): Promise<void>
  reset(): void
  loadChats(): Promise<void>
  loadBlocked(): Promise<void>
  unblock(userId: string): Promise<void>
  openChat(chatId: string): Promise<void>
  closeChat(): void
  loadHistory(chatId: string, before?: number): Promise<void>
  _loadHistory(chatId: string, before?: number): Promise<void>
  sendDraft(chatId: string, draft: SendDraft): Promise<void>
  setTyping(on: boolean): void
  editMessage(chatId: string, id: string, text: string): Promise<void>
  deleteForEveryone(chatId: string, ids: string[]): void
  deleteForMe(chatId: string, ids: string[]): Promise<void>
  finishVanish(chatId: string, ids: string[]): void
  toggleReaction(chatId: string, id: string, emoji: string): void
  toggleStar(msg: Message): Promise<void>
  togglePinMessage(chatId: string, id: string): void
  patchChatState(chatId: string, patch: Record<string, any>): Promise<void>
  markRead(chatId: string): void
  mergeCallSession(chatId: string, userId: string, sessionId: string): void
  setReplying(m: Message | null): void
  localSearch(q: string): Promise<Message[]>
  starredList(): Promise<Message[]>
  exportChat(chatId: string): Promise<void>
  createDm(userId: string): Promise<{ chatId?: string; request?: boolean }>
  createGroup(title: string, description: string, memberIds: string[], limit?: number): Promise<string>
  joinInvite(code: string): Promise<string>
  respondRequest(id: string, accept: boolean): Promise<void>
  loadRequests(): Promise<void>
  _event(chatId: string, ev: any): void
  _hub(ev: any): void
}

export const useChats = create<ChatsState>((set, get) => ({
  booted: false,
  chats: {},
  messages: {},
  loadedAll: {},
  activeChatId: null,
  presence: {},
  requests: [],
  vanish: {},
  starredIds: {},
  seenBy: {},
  replyingTo: null,
  blockedIds: {},

  async boot() {
    if (get().booted) return
    handlers.onChat = (chatId, ev) => get()._event(chatId, ev)
    handlers.onHub = (ev) => get()._hub(ev)
    // (রি)কানেক্ট হলে মিস হওয়া মেসেজ/চ্যাটলিস্ট নিজ থেকেই মিলিয়ে নেওয়া
    handlers.onChatOpen = (chatId) => { get().loadHistory(chatId).catch(() => {}) }
    handlers.onHubOpen = () => { get().loadChats().catch(() => {}); get().loadRequests().catch(() => {}); get().loadBlocked().catch(() => {}) }
    connectHub()
    set({ booted: true })
    await get().loadChats()
    get().loadRequests().catch(() => {})
    get().loadBlocked().catch(() => {})
    const stars = await idb.allKeys('starred')
    const starredIds: Record<string, boolean> = {}
    for (const k of stars) starredIds[String(k)] = true
    set({ starredIds })
    startPresencePoll()
  },

  // ইউজার বদলালে/লগআউটে পুরো স্টোর রিসেট — নইলে একই ডিভাইসে user1 লগআউট
  // করে user2 লগইন করলে user1-এর চ্যাট-লিস্ট ইন-মেমরিতে রয়ে গিয়ে user2-এর
  // চ্যাটে দেখা যেত (booted=true থাকায় নতুন loadChats-ই চলত না)।
  reset() {
    stopPresencePoll()
    resetSockets()
    set({
      booted: false, chats: {}, messages: {}, loadedAll: {},
      activeChatId: null, presence: {}, requests: [], vanish: {},
      starredIds: {}, seenBy: {}, replyingTo: null, blockedIds: {},
    })
  },

  async loadBlocked() {
    try {
      const { results } = await api('/me/blocked')
      const blockedIds: Record<string, boolean> = {}
      for (const r of results || []) blockedIds[r.id] = true
      set({ blockedIds })
    } catch {}
  },

  async unblock(userId) {
    await api(`/me/blocked/${userId}`, { method: 'DELETE' }).catch(() => {})
    set((s) => {
      const blockedIds = { ...s.blockedIds }
      delete blockedIds[userId]
      return { blockedIds }
    })
  },

  async loadChats() {
    const me = useAuth.getState().user?.id
    const { chats: rows } = await api('/chats')
    const chats: Record<string, Chat> = {}
    for (const r of rows) {
      const c: Chat = {
        id: r.id, kind: r.kind, title: r.title || '', photoKey: r.photo_key || '',
        description: r.description || '', memberLimit: r.member_limit,
        members: [],
        pinned: !!r.pinned, archived: !!r.archived, mutedUntil: r.muted_until || 0,
        wallpaper: r.wallpaper || '', ttl: r.ttl || 0,
        unread: r.unread || 0, lastTs: r.last_ts || 0,
      }
      chats[r.id] = c
    }
    // DM-এর জন্য পিয়ার তথ্য
    const dmChats = rows.filter((r: any) => r.kind === 'dm')
    if (dmChats.length) {
      for (const r of dmChats) {
        try {
          const detail = await api(`/chats/${r.id}`)
          const peer = detail.members.find((m: any) => m.id !== me)
          if (peer) {
            chats[r.id].peer = {
              id: peer.id, username: peer.username, about: peer.about,
              avatarKey: peer.avatar_key, deleted: !!peer.deleted,
              // লাস্ট-সিন আগে কখনোই পিয়ারে বসানো হতো না — হেডারে চিরকাল
              // "অনেক দিন আগে" দেখাত। এখন members-কোয়েরি এটা ফেরত দেয়।
              lastSeenAt: peer.last_seen_at || 0,
              lastSeenPriv: peer.lastseen_priv,
            }
            chats[r.id].members = detail.members
          }
        } catch {}
      }
    }
    // গ্রুপ মেম্বার (ছোট স্কেল — প্রতি গ্রুপে ১টি কল)
    for (const r of rows.filter((x: any) => x.kind === 'group')) {
      try {
        const detail = await api(`/chats/${r.id}`)
        chats[r.id].members = detail.members
      } catch {}
    }
    set({ chats })
    // লোকাল ক্যাশ থেকে শেষ মেসেজ প্রিভিউ
    for (const id of Object.keys(chats)) {
      const cached = await lastLocalMessage(id)
      if (cached) set((s) => ({ chats: { ...s.chats, [id]: { ...s.chats[id], lastPreview: previewOf(cached), lastTs: cached.ts } } }))
    }
  },

  async openChat(chatId) {
    const me = useAuth.getState().user?.id
    if (!get().chats[chatId]) {
      try {
        const detail = await api(`/chats/${chatId}`)
        const c = detail.chat
        const chat: Chat = {
          id: c.id, kind: c.kind, title: c.title, photoKey: c.photo_key, description: c.description,
          memberLimit: c.member_limit, members: detail.members, unread: 0,
        }
        if (c.kind === 'dm') {
          const peer = detail.members.find((m: any) => m.id !== me)
          if (peer) chat.peer = {
            id: peer.id, username: peer.username, about: peer.about,
            avatarKey: peer.avatar_key, deleted: !!peer.deleted,
            lastSeenAt: peer.last_seen_at || 0, lastSeenPriv: peer.lastseen_priv,
          }
        }
        set((s) => ({ chats: { ...s.chats, [chatId]: chat } }))
      } catch {}
    } else if (get().chats[chatId]?.kind === 'dm') {
      // চ্যাট খোলার সময় পিয়ারের লাস্ট-সিন একবার ফ্রেশ করি —
      // স্টোরে পুরনো স্ন্যাপশট রয়ে গিয়ে "onek din age" দেখাত।
      const peer = get().chats[chatId].peer
      if (peer) {
        api(`/users/${peer.id}`).then((r: any) => {
          if (r?.user) set((s) => ({
            chats: s.chats[chatId] ? {
              ...s.chats,
              [chatId]: { ...s.chats[chatId], peer: { ...s.chats[chatId].peer!, lastSeenAt: r.user.lastSeenAt || 0, lastSeenPriv: r.user.lastSeenPriv } },
            } : s.chats,
          }))
        }).catch(() => {})
      }
    }
    set({ activeChatId: chatId })
    connectChat(chatId)
    if (!get().messages[chatId]) {
      set((s) => ({ messages: { ...s.messages, [chatId]: [] } }))
      await get().loadHistory(chatId)
    }
    get().markRead(chatId)
  },

  closeChat() {
    const id = get().activeChatId
    if (id) disconnectChat(id)
    set({ activeChatId: null, replyingTo: null })
  },

  async loadHistory(chatId, before) {
    // একই চ্যাটের সমান্তরাল দুটি লোড (openChat + সকেট-ওপেন দুটোই ডাকত)
    // একই রো দুবার প্রসেস করত — র‍্যামচেট-কী দুবার খরচ হয়ে দ্বিতীয়বার
    // OperationError, আর sender-key ইনজেস্টও দুবার চলত। ইন-ফ্লাইট শেয়ার।
    const key = chatId + ':' + (before || '')
    const running = historyInflight.get(key)
    if (running) return running
    const p = get()._loadHistory(chatId, before).finally(() => historyInflight.delete(key))
    historyInflight.set(key, p)
    return p
  },

  async _loadHistory(chatId, before) {
    const rows = await api(`/chats/${chatId}/messages?before=${before || ''}&limit=80`)
    const known = new Set((get().messages[chatId] || []).map((m) => m.id))
    // "শুধু আমার থেকে ডিলিট"-এর টম্বস্টোন — রিলোডে সার্ভার-হিস্টোরি
    // থেকে মেসেজ ফিরে আসা আটকাই (গ্রুপ-মেসেজ রি-ডিক্রিপ্টযোগ্য বলে ফিরত)।
    let tomb: string[] = []
    try { tomb = (await idb.get('meta', `del:${chatId}`)) || [] } catch {}
    const tombSet = new Set(tomb)
    const me = useAuth.getState().user?.id

    // ── পাস ১: sender-key রো আগে ইনজেস্ট ──
    // সার্ভার ASC অর্ডারে রো দেয়, আর sk-মেসেজের ts প্রায়ই এনক্রিপ্ট-করা
    // মেসেজের ts-এর পরে। কী-এর আগে মেসেজ প্রসেস হলে "sender key missing"
    // হয়ে মেসেজ ব্ল্যাকলিস্টে যেত — গ্রুপের প্রথম-খোলা মেসেজ পেজ
    // রিলোড পর্যন্ত অদৃশ্য থাকত।
    for (const r of rows.messages) {
      if (r.type !== 'sender-key' || !r.mid) continue
      if (known.has(r.mid) || skDoneIds.has(r.mid) || tombSet.has(r.mid)) continue
      if (r.sender_id === me) { skDoneIds.add(r.mid); continue }
      try {
        if (await sk.hasSenderKey(chatId, r.sender_id)) { skDoneIds.add(r.mid); continue }
        const payload = typeof r.payload === 'string' ? JSON.parse(r.payload) : r.payload
        const plain = await decryptFrom(r.sender_id, payload as Envelope)
        if (plain?.sk) await sk.ingestSenderKey(plain.chatId || chatId, r.sender_id, plain.sk)
        skDoneIds.add(r.mid)
      } catch { /* পিয়ার-সেশন সারলে পরের লোডে আবার চেষ্টা */ }
    }

    // ── পাস ২: সাধারণ মেসেজ-রো ──
    const msgs: Message[] = []
    let decryptFailed = false
    for (const r of rows.messages) {
      if (r.type === 'sender-key') continue
      if (tombSet.has(r.mid) || known.has(r.mid) || failedDecryptIds.has(r.mid)) continue
      const m = await rowToMessage(chatId, r)
      if (m) msgs.push(m)
      else {
        if (failedDecryptIds.has(r.mid)) decryptFailed = true
        // গ্রুপ-মেসেজের কী নেই হলে (নতুন ডিভাইস/ক্যাশ ক্লিয়ার) — সেন্ডারকে পুনর্বণ্টন চাই
        if (!m && r.sender_id !== me && get().chats[chatId]?.kind === 'group') {
          sk.hasSenderKey(chatId, r.sender_id).then((has) => { if (!has) requestSenderKey(chatId) }).catch(() => {})
        }
      }
    }
    set((s) => {
      const existing = s.messages[chatId] || []
      const ids = new Set(msgs.map((m) => m.id))
      const merged = [...msgs, ...existing.filter((m) => !ids.has(m.id))]
      merged.sort((a, b) => a.ts - b.ts)
      // "আর নেই" ফ্ল্যাগ সার্ভার-ফেরত রো-সংখ্যা দিয়ে হিসাব করি — ডিক্রিপ্ট-
      // ব্যর্থ/ডুপ্লিকেট বাদ পড়লেও পেজিনেশন অসময়ে থেমে যেত না।
      return { messages: { ...s.messages, [chatId]: merged }, loadedAll: { ...s.loadedAll, [chatId]: rows.messages.length < 80 } }
    })
    // ডিসঅ্যাপিয়ারিং মেসেজ — লাইভ পাথে নতুনগুলোর টাইমার বসত, হিস্টোরিতে
    // এলে আর বসত না; মেয়াদোত্তীর্ণগুলো চিরকাল দেখা যেত।
    for (const m of msgs) {
      if (!m.expiresAt) continue
      if (m.expiresAt <= Date.now()) get().deleteForMe(chatId, [m.id])
      else scheduleExpiry(chatId, m.id, m.expiresAt)
    }
    // হিস্টোরিতে ডিক্রিপ্ট-ব্যর্থ রো থাকলে এখান থেকেও renego পাঠাই।
    if (decryptFailed && Date.now() - (lastRenego[chatId] || 0) > 10000) {
      const peer = get().chats[chatId]?.peer
      if (me && peer && peer.id !== me) {
        lastRenego[chatId] = Date.now()
        sendChat(chatId, { t: 'renego', chatId, from: me })
      }
    }
  },

  async sendDraft(chatId, draft) {
    const me = useAuth.getState().user!
    const chat = get().chats[chatId]
    if (!chat) return
    const id = uid('m_')
    const ts = Date.now()
    const expiresAt = draft.ttl ? ts + draft.ttl * 1000 : undefined
    const local: Message = {
      id, chatId, senderId: me.id, ts, type: draft.type, body: draft.body,
      media: draft.media, replyTo: draft.replyTo, fwdFrom: draft.fwdFrom,
      reactions: {}, pending: true, expiresAt,
    }
    appendMessage(chatId, local)
    setReplyingPreview(chatId, local)

    try {
      const plain: any = { body: draft.body, media: draft.media, replyTo: draft.replyTo, fwdFrom: draft.fwdFrom, expiresAt }
      let payload: any
      if (chat.kind === 'group') {
        // sk-বণ্টন আগে, আর তার ts মেসেজের ts-এর চেয়ে ছোট — নইলে ASC
        // হিস্টোরিতে কী-এর আগে মেসেজ এসে ডিক্রিপ্ট ব্যর্থ হত।
        await distributeSenderKeys(chatId, chat, ts)
        payload = await sk.groupEncrypt(chatId, me.id, plain)
      } else {
        if (!chat.peer) throw new Error('no peer')
        payload = await encryptFor(chat.peer.id, plain)
      }
      sendChat(chatId, { t: 'msg', chatId, m: { id, ts, type: draft.type, payload } })
      set((s) => ({ messages: { ...s.messages, [chatId]: (s.messages[chatId] || []).map((m) => m.id === id ? { ...m, pending: false } : m) } }))
    } catch (e) {
      set((s) => ({ messages: { ...s.messages, [chatId]: (s.messages[chatId] || []).map((m) => m.id === id ? { ...m, pending: false, failed: true } : m) } }))
      console.error('send failed', e)
    }
    if (get().replyingTo) set({ replyingTo: null })
  },

  setTyping(on) {
    const chatId = get().activeChatId
    if (chatId) sendChat(chatId, { t: 'typing', chatId, on })
  },

  async editMessage(chatId, id, text) {
    const chat = get().chats[chatId]
    if (!chat) return
    const plain: any = { body: text, edited: true }
    let payload: any
    if (chat.kind === 'group') payload = await sk.groupEncrypt(chatId, useAuth.getState().user!.id, plain)
    else payload = await encryptFor(chat.peer!.id, plain)
    sendChat(chatId, { t: 'edit', chatId, id, payload })
    applyEdit(chatId, id, text)
  },

  // "Delete for everyone" — সব ডিভাইসে Thanos-ভ্যানিশ
  deleteForEveryone(chatId, ids) {
    sendChat(chatId, { t: 'delAll', chatId, ids })
    set((s) => ({ vanish: { ...s.vanish, ...Object.fromEntries(ids.map((i) => [i, true])) } }))
  },

  async deleteForMe(chatId, ids) {
    set((s) => ({
      messages: { ...s.messages, [chatId]: (s.messages[chatId] || []).filter((m) => !ids.includes(m.id)) },
    }))
    for (const id of ids) idb.del('messages', id).catch(() => {})
    // টম্বস্টোন রাখি — নইলে রিলোডে সার্ভার-হিস্টোরি থেকে ফিরে আসত
    // (গ্রুপ-মেসেজ রি-ডিক্রিপ্টযোগ্য, ১:১-ও ক্যাশ এখন সব মেসেজে)।
    try {
      const key = `del:${chatId}`
      const t: string[] = (await idb.get('meta', key)) || []
      await idb.put('meta', key, [...new Set([...t, ...ids])]).catch(() => {})
    } catch {}
  },

  finishVanish(chatId, ids) {
    set((s) => {
      const v = { ...s.vanish }
      for (const i of ids) delete v[i]
      return {
        vanish: v,
        messages: { ...s.messages, [chatId]: (s.messages[chatId] || []).filter((m) => !ids.includes(m.id)) },
      }
    })
    for (const id of ids) idb.del('messages', id).catch(() => {})
  },

  toggleReaction(chatId, id, emoji) {
    const me = useAuth.getState().user!.id
    // আগে সবসময় on:true পাঠানো হতো — নিজের রিয়্যাকশন সরানোই যেত না।
    // এখন আমার রিয়্যাকশন আগে থেকে থাকলে বন্ধ (off) করি।
    const msg = (get().messages[chatId] || []).find((m) => m.id === id)
    const on = !(msg?.reactions?.[emoji] || []).includes(me)
    sendChat(chatId, { t: 'react', chatId, id, emoji, on })
    applyReaction(chatId, id, emoji, me, on)
  },

  async toggleStar(msg) {
    const on = !get().starredIds[msg.id]
    set((s) => ({ starredIds: { ...s.starredIds, [msg.id]: on } }))
    if (on) await idb.put('starred', msg.id, { ...msg, starred: true })
    else await idb.del('starred', msg.id)
  },

  togglePinMessage(chatId, id) {
    sendChat(chatId, { t: 'pin', chatId, mid: id })
  },

  async patchChatState(chatId, patch) {
    await api(`/me/chats/${chatId}/state`, { method: 'PATCH', body: patch })
    if (patch.deleteForMe) {
      // "চ্যাট ডিলিট (আমার)" — লোকাল স্টেট থেকেও সরিয়ে দিই, নইলে রিলোড
      // পর্যন্ত মেসেজ/প্রিভিউ দেখে থেকে যেত।
      set((s) => {
        const chats = { ...s.chats }; delete chats[chatId]
        const messages = { ...s.messages }; delete messages[chatId]
        return { chats, messages }
      })
      return
    }
    set((s) => ({ chats: { ...s.chats, [chatId]: { ...s.chats[chatId], ...localStateFromPatch(patch) } } }))
  },

  markRead(chatId) {
    const msgs = get().messages[chatId] || []
    const me = useAuth.getState().user?.id
    // শুধু এখনো "read" হয়নি এমন পিয়ার-মেসেজের রিসিট — আগে প্রতি ফোকাসে
    // সব মেসেজের রিসিট আবার যেত।
    const unreadIds = msgs.filter((m) => m.senderId !== me && !m.read && !m.delivered).map((m) => m.id)
    if (unreadIds.length) sendChat(chatId, { t: 'read', chatId, ids: unreadIds })
    set((s) => ({ chats: { ...s.chats, [chatId]: { ...s.chats[chatId], unread: 0 } } }))
    api(`/me/chats/${chatId}/state`, { method: 'PATCH', body: { unread: 0, lastReadTs: Date.now() } }).catch(() => {})
  },

  // নিজের SFU সেশন-আইডি activeCall.sessions-এ মার্জ — CallOverlay নিজের
  // broadcast ফেরত না পেলেও (বা join-ইভেন্ট আগে পৌঁছালেও) স্টেট সঠিক থাকে।
  mergeCallSession(chatId, userId, sessionId) {
    set((s) => {
      const c = s.chats[chatId]
      if (!c || !sessionId) return {}
      const base = c.activeCall || { sessionId: '', mode: 'audio', startedBy: userId, startedAt: Date.now(), sessions: {} as Record<string, string> }
      const sessions = { ...(base.sessions || {}), [userId]: sessionId }
      return { chats: { ...s.chats, [chatId]: { ...c, activeCall: { ...base, sessions } } } }
    })
  },

  setReplying(m) { set({ replyingTo: m }) },

  async localSearch(q) {
    const all = await idb.all<Message>('messages')
    const needle = q.toLowerCase()
    return all.filter((m) => (m.body || '').toLowerCase().includes(needle)).sort((a, b) => b.ts - a.ts).slice(0, 100)
  },

  async starredList() {
    return (await idb.all<Message>('starred')).sort((a, b) => b.ts - a.ts)
  },

  async exportChat(chatId) {
    const msgs = get().messages[chatId] || []
    const chat = get().chats[chatId]
    const name = (id: string) => chat.members.find((m) => m.id === id)?.username || id
    const lines = msgs.map((m) => `[${new Date(m.ts).toLocaleString()}] ${name(m.senderId)}: ${m.body || `(${m.type})`}`)
    const blob = new Blob([`fcfc chat export — ${chat.title || chat.peer?.username}\n\n${lines.join('\n')}`], { type: 'text/plain' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `fcfc-export-${chatId}.txt`
    a.click()
    URL.revokeObjectURL(a.href)
  },

  async createDm(userId) {
    const res = await api('/chats', { body: { kind: 'dm', with: userId } })
    if (res.request) return { request: true }
    await get().loadChats()
    return { chatId: res.chatId }
  },

  async createGroup(title, description, memberIds, limit = 200) {
    const res = await api('/chats', { body: { kind: 'group', title, description, memberIds, memberLimit: limit } })
    await get().loadChats()
    return res.chatId
  },

  async joinInvite(code) {
    if (!code) throw new Error('invite code required')
    // পোস্ট না করলে ৪০৪ — সার্ভার-রুট POST, ক্লায়েন্ট ডিফল্ট GET পাঠাত
    const res = await api(`/invites/${code}/join`, { method: 'POST' })
    await get().loadChats()
    return res.chatId
  },

  async respondRequest(id, accept) {
    // একই ৪০৪-বাগ — accept/decline রুটও POST
    await api(`/requests/${id}/${accept ? 'accept' : 'decline'}`, { method: 'POST' })
    await get().loadRequests()
    if (accept) await get().loadChats()
  },

  async loadRequests() {
    const { requests } = await api('/me/requests')
    set({ requests })
  },

  // ── ChatRoom WebSocket ইভেন্ট হ্যান্ডলার ──
  async _event(chatId, ev) {
    const me = useAuth.getState().user?.id
    const chat = () => get().chats[chatId]
    switch (ev.t) {
      case 'hello': {
        set((s) => ({ chats: s.chats[chatId] ? { ...s.chats, [chatId]: { ...s.chats[chatId], pins: ev.pins, activeCall: ev.call } } : s.chats }))
        break
      }
      case 'msg': {
        const m = ev.m
        if (m.senderId === me && get().messages[chatId]?.some((x) => x.id === m.id)) return
        const msg = await rowToMessage(chatId, { mid: m.id, sender_id: m.senderId, ts: m.ts, type: m.type, payload: m.payload })
        if (!msg) {
          // ডিক্রিপ্ট ব্যর্থ → পাঠানোর পক্ষকে র‍্যামচেট রি-নেগো করার সংকেত (১০ সেকেন্ডে সর্বোচ্চ ১বার)
          // ⚠️ sender-key / call মেসেজ ইচ্ছাকৃতভাবে null রিটার্ন করে — সেগুলো "ব্যর্থ" নয়,
          // আগে সেগুলোর জন্যও renego যেত (অকারণ সেশন-চার্ন)।
          if (m.senderId !== me && m.type !== 'sender-key' && m.type !== 'call' && Date.now() - (lastRenego[chatId] || 0) > 10000) {
            lastRenego[chatId] = Date.now()
            sendChat(chatId, { t: 'renego', chatId, from: me })
          }
          // গ্রুপে কী নেই — সেন্ডারকে পুনর্বণ্টন চাই
          if (m.senderId !== me && chat()?.kind === 'group' && m.type !== 'sender-key' && m.type !== 'call') {
            sk.hasSenderKey(chatId, m.senderId).then((has) => { if (!has) requestSenderKey(chatId) }).catch(() => {})
          }
          return
        }
        // লাইভ মেসেজ ডিক্রিপ্ট সফল = সেশন সেরে গেছে — এই চ্যাটে আগে ব্ল্যাকলিস্ট
        // হওয়া পুরনো মেসেজগুলো আর কখনো রিট্রাই হতো না (রিলোড পর্যন্ত উধাও)।
        // ব্ল্যাকলিস্ট মুছে হিস্ট্রি আবার মার্জ করি — গ্যাপ নিজে থেকেই ভরে যায়।
        if (healFailedChat(chatId)) get().loadHistory(chatId).catch(() => {})
        appendMessage(chatId, msg)
        setReplyingPreview(chatId, msg)
        if (m.senderId !== me) {
          sendChat(chatId, { t: 'delivered', chatId, ids: [m.id] })
          if (get().activeChatId === chatId) {
            get().markRead(chatId)
          } else {
            set((s) => ({ chats: { ...s.chats, [chatId]: { ...s.chats[chatId], unread: (s.chats[chatId]?.unread || 0) + 1 } } }))
            const c = chat()
            if (c && !(c.mutedUntil && c.mutedUntil > Date.now())) {
              notifyMessage(c, msg)
              if (useAuth.getState().settings?.sound !== false) playPing()
            }
          }
        }
        if (msg.expiresAt) scheduleExpiry(chatId, msg.id, msg.expiresAt)
        break
      }
      case 'msg-rejected': {
        // সার্ভার মেসেজ নেয়নি (ব্লকড পিয়ার / পেন্ডিং রিকোয়েস্ট) — আগে
        // প্রেরকের UI-তে ভুয়া "পাঠানো" মেসেজ রয়ে গিয়ে রিলোডে উধাও হতো।
        set((s) => ({
          messages: {
            ...s.messages,
            [chatId]: (s.messages[chatId] || []).map((m) => m.id === ev.id ? { ...m, pending: false, failed: true } : m),
          },
        }))
        const rejected = (get().messages[chatId] || []).find((x) => x.id === ev.id)
        if (rejected) idb.put('messages', rejected.id, { ...rejected, failed: true }).catch(() => {})
        useUi.getState().toast(t('msgRejected'))
        break
      }
      case 'delivered':
      case 'read': {
        if (ev.from === me) return
        set((s) => {
          const seenBy = { ...s.seenBy }
          if (ev.t === 'read') {
            for (const id of ev.ids) seenBy[id] = [...new Set([...(seenBy[id] || []), ev.from])]
          }
          return {
            seenBy,
            messages: {
              ...s.messages,
              [chatId]: (s.messages[chatId] || []).map((m) =>
                ev.ids.includes(m.id) && m.senderId === me ? { ...m, [ev.t === 'read' ? 'read' : 'delivered']: true } : m),
            },
          }
        })
        break
      }
      case 'typing': {
        if (ev.from === me) return
        set((s) => {
          const c = s.chats[chatId]
          if (!c) return s
          let typing = c.typing || []
          typing = ev.on ? [...new Set([...typing, ev.from])] : typing.filter((u) => u !== ev.from)
          return { chats: { ...s.chats, [chatId]: { ...c, typing } } }
        })
        if (ev.on) setTimeout(() => {
          set((s) => {
            const c = s.chats[chatId]
            if (!c) return s
            return { chats: { ...s.chats, [chatId]: { ...c, typing: (c.typing || []).filter((u) => u !== ev.from) } } }
          })
        }, 6000)
        break
      }
      case 'presence': {
        set((s) => ({ presence: { ...s.presence, [ev.userId]: ev.online } }))
        // অফলাইনে গেলেই পিয়ারের লাস্ট-সিন এখনই বসিয়ে দিই — সার্ভার যে-মুহূর্তে
        // DB-তে লিখছে, ক্লায়েন্টও সেই মুহূর্ত দেখাক। আগে পুরনো স্ন্যাপশট রয়ে যেত।
        if (ev.online === false) {
          set((s) => {
            const chats = { ...s.chats }
            let changed = false
            for (const c of Object.values(chats)) {
              if (c.kind === 'dm' && c.peer?.id === ev.userId) {
                chats[c.id] = { ...c, peer: { ...c.peer!, lastSeenAt: Date.now() } }
                changed = true
              }
            }
            return changed ? { chats } : {}
          })
        }
        break
      }
      case 'renego': {
        // ওপক্ষের ডিক্রিপশন ভেঙেছে — ওর সাথে পুরনো র‍্যামচেট সেশন ফেলে দিই,
        // পরের মেসেজটা নতুন হ্যান্ডশেকসহ যাবে
        if (ev.from && ev.from !== me) idb.del('sessions', ev.from).catch(() => {})
        break
      }
      case 'skrequest': {
        // ওপক্ষের (গ্রুপ-সেন্ডার) কাছে আমার সেন্ডার-কী নেই — পুনঃবণ্টনের
        // ট্র্যাকিং থেকে ওকে বাদ দিলে পরের মেসেজেই কী আবার যাবে
        if (ev.from && ev.from !== me && ev.chatId) sk.markNeedsRedistribution(ev.chatId, [ev.from]).catch(() => {})
        break
      }
      case 'edit': {
        try {
          const c = chat()
          if (!c) return
          const plain = c.kind === 'group'
            ? await sk.groupDecrypt(chatId, ev.from, ev.payload)
            : await decryptFrom(ev.from, ev.payload as Envelope)
          applyEdit(chatId, ev.id, plain.body)
        } catch {}
        break
      }
      case 'delAll': {
        // সব ডিভাইসে একসাথে ভ্যানিশ অ্যানিমেশন
        const ids: string[] = ev.ids || []
        set((s) => ({ vanish: { ...s.vanish, ...Object.fromEntries(ids.map((i) => [i, true])) } }))
        break
      }
      case 'react': {
        applyReaction(chatId, ev.id, ev.emoji, ev.from, ev.on)
        break
      }
      case 'pins': {
        set((s) => ({ chats: s.chats[chatId] ? { ...s.chats, [chatId]: { ...s.chats[chatId], pins: ev.pins } } : s.chats }))
        break
      }
      case 'call': {
        set((s) => ({ chats: s.chats[chatId] ? { ...s.chats, [chatId]: { ...s.chats[chatId], activeCall: ev.call } } : s.chats }))
        break
      }
    }
  },

  // ── UserHub ইভেন্ট ──
  async _hub(ev) {
    const { openModal, toast } = useUi.getState()
    switch (ev.t) {
      case 'device-approval':
        openModal('device-approval', { deviceId: ev.deviceId, deviceName: ev.deviceName })
        break
      case 'device-revoked':
        // Telegram-style Decline: আমার নিজের সেশনই রিভোক হলে → তৎক্ষণাৎ লগআউট
        if (ev.deviceId && ev.deviceId === deviceId()) {
          useAuth.getState().forceLogout()
        }
        break
      case 'request-declined': {
        // আমার পাঠানো রিকোয়েস্ট বাতিল — লোকাল চ্যাটও সরে যায়
        const s = get()
        if (ev.chatId && s.chats[ev.chatId]) {
          const chats = { ...s.chats }
          delete chats[ev.chatId]
          set({ chats, activeChatId: s.activeChatId === ev.chatId ? null : s.activeChatId })
        }
        break
      }
      case 'message-request':
        get().loadRequests()
        toast(t('newReqToast'))
        break
      case 'request-accepted':
        await get().loadChats()
        toast(t('reqAcceptedToast'))
        break
      case 'chat-new':
        await get().loadChats()
        break
      case 'chat-updated':
        await get().loadChats()
        break
      case 'members-changed': {
        if (Array.isArray(ev.added) && !ev.added.includes(useAuth.getState().user?.id)) {
          await sk.markNeedsRedistribution(ev.chatId, ev.added)
        }
        await get().loadChats()
        break
      }
      case 'removed-from-chat': {
        const s = get()
        const chats = { ...s.chats }
        delete chats[ev.chatId]
        set({ chats, activeChatId: s.activeChatId === ev.chatId ? null : s.activeChatId })
        break
      }
      case 'msg': {
        // অন্য চ্যাটে নতুন মেসেজ (হাব হয়ে এসেছে)
        const c = get().chats[ev.chatId]
        if (c) set((st) => ({ chats: { ...st.chats, [ev.chatId]: { ...c, unread: c.unread + 1, lastTs: Date.now() } } }))
        if (c && !(c.mutedUntil && c.mutedUntil > Date.now())) {
          const sender = ev.from
          notifyMessage(c, { id: ev.mid, chatId: ev.chatId, senderId: sender, ts: Date.now(), type: 'text', body: t('newEncryptedMsg'), reactions: {} })
          if (useAuth.getState().settings?.sound !== false) playPing()
        }
        break
      }
    }
  },
}))

// ── হেল্পার ─────────────────────────────────────────────────
import { useUi } from './ui'

export function previewOf(m: Message): string {
  switch (m.type) {
    case 'text': return m.body || ''
    case 'image': return t('pImage')
    case 'video': return t('pVideo')
    case 'voice': return t('pVoice')
    case 'file': return `📎 ${m.media?.name || t('fileLabel')}`
    case 'sticker': return t('pSticker')
    case 'gif': return t('pGif')
    case 'call': return t('pCall')
    default: return ''
  }
}

function appendMessage(chatId: string, msg: Message) {
  useChats.setState((s) => {
    const list = s.messages[chatId] || []
    if (list.some((m) => m.id === msg.id)) return s
    return { messages: { ...s.messages, [chatId]: [...list, msg].sort((a, b) => a.ts - b.ts) } }
  })
  // লোকাল সার্চ ইনডেক্স + নিজের-মেসেজ ক্যাশ — ক্যাপশন-ছাড়া মিডিয়াও ক্যাশ হয়
  // (নইলে রিলোডের পরে নিজের পাঠানো ছবি/ভয়েস আর দেখা যেত না)।
  if ((msg.body || msg.media) && msg.type !== 'sender-key') { markBackupDirty(); idb.put('messages', msg.id, { ...msg, payload: undefined }).catch(() => {}) }
}

function setReplyingPreview(chatId: string, msg: Message) {
  useChats.setState((s) => ({
    chats: { ...s.chats, [chatId]: { ...s.chats[chatId], lastPreview: previewOf(msg), lastTs: msg.ts } },
  }))
}

// রি-নেগো থ্রটল + যে মেসেজ ডিক্রিপ্ট করা যায়নি সেগুলোর তালিকা (বারবার চেষ্টা এড়াতে)
const lastRenego: Record<string, number> = {}
// mid → chatId: কোন চ্যাটে কোন মেসেজ-রো ডিক্রিপ্ট-ব্যর্থ হলো। আগে একটা
// গ্লোবাল Set ছিল — একবার ব্যর্থ হলে সেশন সেরে গেলেও রিট্রাই হতো না
// (মেসেজগুলো রিলোড পর্যন্ত উধাও থাকত)। এখন লাইভ-মেসেজ সফল হলে
// healFailedChat() ওই চ্যাটের ব্ল্যাকলিস্ট মুছে হিস্ট্রি রি-মার্জ করে।
const failedDecryptIds = new Map<string, string>()
function healFailedChat(chatId: string): boolean {
  let healed = false
  for (const [mid, cid] of failedDecryptIds) {
    if (cid === chatId) { failedDecryptIds.delete(mid); healed = true }
  }
  return healed
}
// ইনজেস্ট-হওয়া sender-key রো + চলমান হিস্টোরি-লোড — ডাবল-প্রসেস আটকাই
const skDoneIds = new Set<string>()
const historyInflight = new Map<string, Promise<void>>()
// গ্রুপ-কী না থাকলে সেন্ডারকে পুনর্বণ্টনের অনুরোধ (১০ সেকেন্ডে সর্বোচ্চ ১বার)
const lastSkReq: Record<string, number> = {}
function requestSenderKey(chatId: string) {
  if (Date.now() - (lastSkReq[chatId] || 0) < 10000) return
  lastSkReq[chatId] = Date.now()
  sendChat(chatId, { t: 'skrequest', chatId })
}

async function rowToMessage(chatId: string, row: any): Promise<Message | null> {
  try {
    let payload = typeof row.payload === 'string' ? JSON.parse(row.payload) : row.payload
    const me = useAuth.getState().user?.id

    if (row.type === 'sender-key') {
      // বন্টন করা সেন্ডার-কী ইনজেস্ট করি
      if (row.sender_id !== me) {
        const plain = await decryptFrom(row.sender_id, payload as Envelope)
        if (plain?.sk) await sk.ingestSenderKey(plain.chatId || chatId, row.sender_id, plain.sk)
      }
      return null
    }
    if (row.type === 'call') return null

    // CACHE-FIRST-FOR-ALL: রিসিভ করা মেসেজও ডিক্রিপ্টেড-ক্যাশ থেকে ফেরত —
    // র‍্যামচেট কী একবারই খরচ হয়; রিলোডে পুনঃডিক্রিপ্ট OperationError দিত।
    const cachedAll = await idb.get<Message>('messages', row.mid)
    if (cachedAll) {
      return { ...cachedAll, reactions: payload.reactions || {}, pending: false, failed: false }
    }

    // ── নিজের পাঠানো মেসেজ ──
    // 1:1-তে নিজের এনভেলপ নিজে ডিক্রিপ্ট করা যায় না (ওটা পিয়ারের জন্যই
    // এনক্রিপ্টেড) — লোকাল ক্যাশ থেকে রেন্ডার হয়। গ্রুপে নিজের সেন্ডার-কী
    // চেইন থেকে পুরনো মেসেজ-কী বানিয়ে ডিক্রিপ্ট করা যায়।
    if (row.sender_id === me) {
      if (payload.g === 1) {
        const plain = await sk.groupDecryptOwn(chatId, payload)
        const own: Message = {
          id: row.mid, chatId, senderId: row.sender_id, ts: row.ts, type: row.type,
          body: plain.body, media: plain.media, replyTo: plain.replyTo, fwdFrom: plain.fwdFrom,
          editedAt: plain.edited ? row.ts : undefined, expiresAt: plain.expiresAt,
          reactions: payload.reactions || {},
        }
        // ক্যাশে রাখি — পরের রিলোডে আর চেইন-রিপ্লে লাগবে না
        if (own.body || own.media) idb.put('messages', row.mid, own).catch(() => {})
        return own
      }
      return null // নিজের 1:1 মেসেজ, ক্যাশ নেই (যেমন অন্য ডিভাইস থেকে পাঠানো) — বাদ
    }

    let plain: any
    if (payload.g === 1) {
      // গ্রুপ মেসেজ — চ্যাটের মেম্বার হলেই সেন্ডার-কী থাকে; না থাকলে এররই ঠিক
      plain = await sk.groupDecrypt(chatId, row.sender_id, payload)
    } else {
      plain = await decryptFrom(row.sender_id, payload as Envelope)
    }
    return {
      id: row.mid, chatId, senderId: row.sender_id, ts: row.ts, type: row.type,
      body: plain.body, media: plain.media, replyTo: plain.replyTo, fwdFrom: plain.fwdFrom,
      editedAt: plain.edited ? row.ts : undefined, expiresAt: plain.expiresAt,
      reactions: payload.reactions || {},
    }
  } catch (e) {
    console.warn('decrypt failed', row.mid, e)
    // sender-key rows are not blacklisted: a healed peer session
    // should retry on the next load (group history depends on it)
    if (row.type !== 'sender-key') failedDecryptIds.set(row.mid, chatId)
    return null
  }
}

function applyEdit(chatId: string, id: string, text: string) {
  useChats.setState((s) => ({
    messages: {
      ...s.messages,
      [chatId]: (s.messages[chatId] || []).map((m) => (m.id === id ? { ...m, body: text, editedAt: Date.now() } : m)),
    },
  }))
  idb.get('messages', id).then((m) => { if (m) { markBackupDirty(); idb.put('messages', id, { ...m, body: text, editedAt: Date.now() }) } })
}

function applyReaction(chatId: string, id: string, emoji: string, userId: string, on: boolean) {
  useChats.setState((s) => ({
    messages: {
      ...s.messages,
      [chatId]: (s.messages[chatId] || []).map((m) => {
        if (m.id !== id) return m
        const reactions = { ...m.reactions }
        const list = reactions[emoji] || []
        reactions[emoji] = on ? [...new Set([...list, userId])] : list.filter((u) => u !== userId)
        if (!reactions[emoji].length) delete reactions[emoji]
        return { ...m, reactions }
      }),
    },
  }))
}

async function lastLocalMessage(chatId: string): Promise<Message | null> {
  const all = await idb.all<Message>('messages')
  const mine = all.filter((m) => m.chatId === chatId && m.type !== 'sender-key')
  return mine.sort((a, b) => b.ts - a.ts)[0] || null
}

function localStateFromPatch(patch: Record<string, any>): Partial<Chat> {
  const out: Partial<Chat> = {}
  if (typeof patch.pinned === 'boolean') out.pinned = patch.pinned
  if (typeof patch.archived === 'boolean') out.archived = patch.archived
  if (typeof patch.mutedUntil === 'number') out.mutedUntil = patch.mutedUntil
  if (typeof patch.wallpaper === 'string') out.wallpaper = patch.wallpaper
  if (typeof patch.ttl === 'number') out.ttl = patch.ttl
  return out
}

// ডিসঅ্যাপিয়ারিং মেসেজ টাইমার
const expiryTimers = new Map<string, any>()
function scheduleExpiry(chatId: string, msgId: string, expiresAt: number) {
  if (expiryTimers.has(msgId)) return
  const delay = Math.max(0, expiresAt - Date.now())
  expiryTimers.set(msgId, setTimeout(() => {
    expiryTimers.delete(msgId)
    useChats.getState().deleteForEveryone(chatId, [msgId])
  }, delay))
}

async function distributeSenderKeys(chatId: string, chat: Chat, beforeTs?: number) {
  const me = useAuth.getState().user!.id
  const distributed = await sk.distributedSet(chatId)
  const targets = chat.members.filter((m) => m.id !== me && !m.deleted && !distributed.has(m.id))
  if (!targets.length) return
  const pkg = await sk.distributionPackage(chatId)
  for (const t of targets) {
    try {
      const env = await encryptFor(t.id, { sk: pkg, chatId })
      sendChat(chatId, {
        t: 'msg', chatId,
        // ts মেসেজের চেয়ে এক টিক আগে — ASC হিস্টোরিতে কী আগে আসে
        m: { id: uid('sk_'), ts: beforeTs ? beforeTs - 1 : Date.now(), type: 'sender-key', payload: env },
      })
      await sk.markDistributed(chatId, t.id)
    } catch (e) {
      console.warn('sender key distribution failed for', t.id, e)
    }
  }
}

// ── প্রেজেন্স পোলিং ──
// চ্যাট-রুম সকেট শুধু খোলা চ্যাটের প্রেজেন্স-ইভেন্ট দেয়; লিস্টের বাকি
// পিয়ারদের অনলাইন/অফলাইন আর লাস্ট-সিন কেউ আপডেট করত না। প্রতি ৬০
// সেকেন্ডে KV-ভিত্তিক /users/presence পোল করে ডট-স্ট্যাটাস ফ্রেশ রাখি,
// আর সক্রিয় চ্যাটের পিয়ারের লাস্ট-সিনও একবার রিফ্রেশ করি।
let presenceTimer: any = null

function startPresencePoll() {
  stopPresencePoll()
  presenceTimer = setInterval(async () => {
    try {
      const s = useChats.getState()
      const me = useAuth.getState().user?.id
      const peerIds = Object.values(s.chats)
        .filter((c) => c.kind === 'dm' && c.peer && c.peer.id !== me && !c.peer.deleted)
        .map((c) => c.peer!.id)
      if (!peerIds.length) return
      const out = await api(`/users/presence?ids=${encodeURIComponent(peerIds.join(','))}`)
      useChats.setState((st) => ({ presence: { ...st.presence, ...out } }))
      // সক্রিয় DM-চ্যাটের পিয়ারের লাস্ট-সিন রিফ্রেশ
      const active = s.chats[s.activeChatId || '']
      if (active?.kind === 'dm' && active.peer) {
        api(`/users/${active.peer.id}`).then((r: any) => {
          if (r?.user) {
            useChats.setState((st) => {
              const c = st.chats[active.id]
              if (!c || !c.peer || c.peer.id !== r.user.id) return st
              return { chats: { ...st.chats, [c.id]: { ...c, peer: { ...c.peer, lastSeenAt: r.user.lastSeenAt || 0 } } } }
            })
          }
        }).catch(() => {})
      }
    } catch {}
  }, 60_000)
}

function stopPresencePoll() {
  if (presenceTimer) { clearInterval(presenceTimer); presenceTimer = null }
}
