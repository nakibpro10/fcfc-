// UI স্টেট — থিম, মডাল, টোস্ট, কল, ভিউয়ার, কনটেক্সট মেনু, অ্যাভাটার-ভিউয়ার।
import { create } from 'zustand'
import type React from 'react'

export interface MenuItem {
  label: string
  danger?: boolean
  onClick: () => void
  icon?: React.ReactNode // জেল-টাইল SVG আইকন (ইমোজির বদলে)
}

interface UiState {
  theme: 'light' | 'dark'
  panel: null | 'settings' | 'archived' | 'starred'
  modal: { type: string; props?: any } | null
  viewer: { urls: string[]; index: number; name?: string } | null
  avatarView: { name: string; id: string; avatarKey?: string } | null
  call: { chatId: string; mode: 'audio' | 'video'; incoming?: any } | null
  menu: { x: number; y: number; items: MenuItem[] } | null
  toasts: { id: number; text: string }[]
  mobileView: 'list' | 'chat'

  toggleTheme(): void
  setPanel(p: UiState['panel']): void
  openModal(type: string, props?: any): void
  closeModal(): void
  openViewer(urls: string[], index?: number, name?: string): void
  closeViewer(): void
  openAvatarView(name: string, id: string, avatarKey?: string): void
  closeAvatarView(): void
  setCall(c: UiState['call']): void
  openMenu(x: number, y: number, items: MenuItem[]): void
  closeMenu(): void
  toast(text: string): void
  setMobileView(v: UiState['mobileView']): void
}

let toastId = 0

// PWA থিম-কালার — অ্যাপের থিমের সাথে মিলিয়ে স্ট্যাটাস-বার/টাইটেল-বারের রঙ।
// (আগে হার্ডকোড নীল ছিল — লাইট/ডার্ক যা-ই হোক নীলই থাকত।)
export function applyThemeColor(theme: 'light' | 'dark') {
  const color = theme === 'dark' ? '#0e1220' : '#ffffff'
  try {
    let el = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]:not([media])')
    if (!el) {
      el = document.createElement('meta')
      el.name = 'theme-color'
      document.head.appendChild(el)
    }
    el.content = color
  } catch {}
}

export const useUi = create<UiState>((set, get) => ({
  theme: document.documentElement.classList.contains('dark') ? 'dark' : 'light',
  panel: null,
  modal: null,
  viewer: null,
  avatarView: null,
  call: null,
  menu: null,
  toasts: [],
  mobileView: 'list',

  toggleTheme() {
    const t = get().theme === 'dark' ? 'light' : 'dark'
    document.documentElement.classList.toggle('dark', t === 'dark')
    localStorage.setItem('fcfc.theme', t)
    applyThemeColor(t)
    set({ theme: t })
  },
  setPanel(p) { set({ panel: p }) },
  openModal(type, props) { set({ modal: { type, props } }) },
  closeModal() { set({ modal: null }) },
  openViewer(urls, index = 0, name) { set({ viewer: { urls, index, name } }) },
  closeViewer() { set({ viewer: null }) },
  openAvatarView(name, id, avatarKey) { set({ avatarView: { name, id, avatarKey } }) },
  closeAvatarView() { set({ avatarView: null }) },
  setCall(c) { set({ call: c }) },
  openMenu(x, y, items) { set({ menu: { x, y, items } }) },
  closeMenu() { set({ menu: null }) },
  toast(text) {
    const id = ++toastId
    set({ toasts: [...get().toasts, { id, text }] })
    setTimeout(() => set({ toasts: get().toasts.filter((t) => t.id !== id) }), 3200)
  },
  setMobileView(v) { set({ mobileView: v }) },
}))
