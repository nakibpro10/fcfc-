// পাসওয়ার্ড-ডিরাইভড কী-ব্যাকআপ (মাল্টি-ডিভাইস রিস্টোর)।
// পাসওয়ার্ড থেকে PBKDF2 (600k) দিয়ে কী ডেরাইভ → প্রাইভেট কী বান্ডিল
// ক্লায়েন্ট-সাইডে এনক্রিপ্ট → এনক্রিপ্টেড ব্লব সার্ভারে। সার্ভার কখনো
// ডিক্রিপ্ট করতে পারে না; পাসওয়ার্ড হারালে ব্লব উদ্ধার অসম্ভব।
//
// ⚠️ আগের ভার্সনের মূল সমস্যা: ব্যাকআপ হতো শুধু সাইনআপ/লগইনের মুহূর্তে —
// তার পরে তৈরি হওয়া র‍্যামচেট-সেশন বা ডিক্রিপ্ট করা মেসেজ-ক্যাশ কখনোই
// ব্যাকআপে ঢুকত না। নতুন ফোনে লগইন করলে সেশন-একেবারে-শূন্য অবস্থায়
// রিস্টোর হতো → পুরো চ্যাট-ইতিহাস "no session and no handshake" এররে
// উধাও — ব্যবহারকারী দেখত খালি চ্যাট। এখন:
//   • ব্যাকআপে messages/starred/meta-ও থাকে (ডিক্রিপ্ট করা ক্যাশ —
//     নতুন ডিভাইসে ইতিহাস ক্যাশ-থেকেই রেন্ডার হয়, রি-ডিক্রিপ্ট লাগে না)
//   • সেশন/মেসেজ বদলালে "dirty" ফ্ল্যাগ উঠে ৪৫ সেকেন্ডের মধ্যেই
//     থ্রটলড সিঙ্ক চলে যায় (startBackupSync)।
import { idb } from '../lib/db'
import { api } from '../api/client'
import { b64u, b64uToBytes } from '../lib/utils'

const ITER = 600_000
// ব্যাকআপে সর্বশেষ কতগুলো মেসেজ-ক্যাশ রাখা হবে — ব্লব-সাইজ সীমিত রাখতে
const MAX_BACKUP_MESSAGES = 800

async function deriveKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey'])
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', hash: 'SHA-256', salt: salt as BufferSource, iterations: ITER },
    base,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  )
}

async function collectBundle(): Promise<string> {
  const stores = ['keys', 'sessions', 'senderKeys', 'starred', 'meta']
  const dump: Record<string, any> = {}
  for (const s of stores) {
    const entries: Record<string, any> = {}
    for (const k of await idb.allKeys(s)) entries[String(k)] = await idb.get(s, k)
    dump[s] = entries
  }
  // মেসেজ-ক্যাশ: পুরোটা নয় — সর্বশেষ MAX_BACKUP_MESSAGES-টা (ts-অনুসারে)
  {
    const all = await idb.all<any>('messages')
    const recent = (all || []).filter((m) => m && typeof m.ts === 'number').sort((a, b) => b.ts - a.ts).slice(0, MAX_BACKUP_MESSAGES)
    const entries: Record<string, any> = {}
    for (const m of recent) entries[String(m.id)] = m
    dump.messages = entries
  }
  return JSON.stringify(dump)
}

export async function createBackup(password: string): Promise<{ blob: string; salt: string }> {
  const salt = crypto.getRandomValues(new Uint8Array(16))
  const key = await deriveKey(password, salt)
  const iv = crypto.getRandomValues(new Uint8Array(12))
  const ct = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv as BufferSource }, key,
    new TextEncoder().encode(await collectBundle()) as BufferSource,
  )
  // layout: iv(12) || ciphertext
  const combined = new Uint8Array(12 + ct.byteLength)
  combined.set(iv, 0)
  combined.set(new Uint8Array(ct), 12)
  return { blob: b64u(combined), salt: b64u(salt) }
}

export async function restoreBackup(password: string, blob: string, saltB64: string): Promise<boolean> {
  try {
    const key = await deriveKey(password, b64uToBytes(saltB64))
    const data = b64uToBytes(blob)
    const iv = data.slice(0, 12)
    const ct = data.slice(12)
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv as BufferSource }, key, ct as BufferSource)
    const dump = JSON.parse(new TextDecoder().decode(plain))
    for (const [store, entries] of Object.entries<any>(dump)) {
      for (const [k, v] of Object.entries(entries)) {
        await idb.put(store, k, v)
      }
    }
    return true
  } catch {
    return false
  }
}

// সাইনআপ/লগইনের পর কল করা হয়: লোকাল কী থাকলে আপলোড, না থাকলে রিস্টোরের চেষ্টা
export async function syncBackup(password: string) {
  const remote = await api('/me/backup')
  const hasLocal = !!(await idb.get('keys', 'identity'))
  if (hasLocal) {
    const { blob, salt } = await createBackup(password)
    await api('/me/backup', { method: 'PUT', body: { blob, salt } })
    return 'uploaded'
  }
  if (remote?.blob) {
    const ok = await restoreBackup(password, remote.blob, remote.salt)
    return ok ? 'restored' : 'failed'
  }
  return 'none'
}

// ── থ্রটলড পর্যায়ক্রমিক সিঙ্ক ──
// সেশন/সেন্ডার-কী/মেসেজ-ক্যাশ বদলালে markBackupDirty() ডাকা হয়; ৪৫ সেকেন্ডের
// টাইমার dirty দেখলেই আপলোড (PBKDF2 600k ভারী — প্রতি মেসেজে নয়, ব্যাচে)।
// পাসওয়ার্ড শুধু লগইন-সেশনে মেমরিতে থাকে — রিলোডের পর সিঙ্ক আগাম লগইন পর্যন্ত
// বন্ধ থাকে (লগইনের সময় একবার পূর্ণ সিঙ্ক হয়েই যায়)।
let dirty = false
let syncTimer: any = null
let syncing = false

export function markBackupDirty() { dirty = true }

// auth স্টোর থেকে সেশন-মেমরি পাসওয়ার্ড (ডাইনামিক ইমপোর্ট — auth.ts নিজেই
// backup.ts ইমপোর্ট করে, স্ট্যাটিক সার্কুলার হয়ে যেত)
async function sessionPassword(): Promise<string | null> {
  try { return (await import('../stores/auth')).useAuth.getState().password || null } catch { return null }
}

export function startBackupSync() {
  stopBackupSync()
  syncTimer = setInterval(async () => {
    if (!dirty || syncing) return
    const password = await sessionPassword()
    if (!password) return
    syncing = true
    try {
      await syncBackup(password)
      dirty = false
    } catch { /* নেটওয়ার্ক পড়লে পরের টিকে আবার */ }
    finally { syncing = false }
  }, 45_000)
  // ট্যাব লুকালে সঙ্গে সঙ্গে একবার — সর্বশেষ অবস্থা যেন জমা থাকে
  document.addEventListener('visibilitychange', onHidden)
}

async function onHidden() {
  if (document.visibilityState !== 'hidden' || !dirty || syncing) return
  const password = await sessionPassword()
  if (!password) return
  dirty = false
  try { await syncBackup(password) } catch { dirty = true }
}

export function stopBackupSync() {
  if (syncTimer) { clearInterval(syncTimer); syncTimer = null }
  document.removeEventListener('visibilitychange', onHidden)
}
